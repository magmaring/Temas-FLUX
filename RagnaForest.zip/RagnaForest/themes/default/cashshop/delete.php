<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>CashShop</h2>
<p>Failed to delete item. <a href="javascript:history.go(-1)">Go back</a>.</p>
