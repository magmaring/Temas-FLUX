ALTER TABLE  `cp_xferlog` ADD INDEX (  `from_account_id` ,  `target_account_id` ,  `target_char_id` ) ;
