ALTER TABLE  `cp_charprefs` ADD INDEX (  `account_id` ,  `char_id` ) ;
