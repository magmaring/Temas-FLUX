ALTER TABLE `cp_itemshop` ADD `category` INT(11) NULL AFTER `nameid`;
