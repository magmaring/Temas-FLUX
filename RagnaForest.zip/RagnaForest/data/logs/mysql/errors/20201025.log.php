<?php exit('Forbidden'); ?>
[2020-10-25 01:16:04] [SQLSTATE=42S02] Err 1146: Table 'ragnarok.rush_mvp' doesn't exist
[2020-10-25 01:16:05] [SQLSTATE=42S22] Err 1054: Unknown column 'cash.date' in 'order clause'
