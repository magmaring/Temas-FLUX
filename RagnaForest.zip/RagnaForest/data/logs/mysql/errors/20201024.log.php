<?php exit('Forbidden'); ?>
[2020-10-24 21:49:21] [SQLSTATE=42S21] Err 1060: Duplicate column name 'use_existing'
[2020-10-24 21:50:34] [SQLSTATE=42S02] Err 1146: Table 'ragnarok.rush_mvp' doesn't exist
[2020-10-24 21:50:34] [SQLSTATE=42S22] Err 1054: Unknown column 'cash.date' in 'order clause'
