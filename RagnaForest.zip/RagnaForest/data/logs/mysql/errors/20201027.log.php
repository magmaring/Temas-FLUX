<?php exit('Forbidden'); ?>
[2020-10-27 07:35:18] [SQLSTATE=42S02] Err 1146: Table 'ragnarok.rush_mvp' doesn't exist
[2020-10-27 07:35:18] [SQLSTATE=42S22] Err 1054: Unknown column 'cash.date' in 'order clause'
