<?php exit('Forbidden'); ?>
[2020-10-24 21:49:21] (Flux_Error) Exception Flux_Error: Critical MySQL error in Installer/Updater: Duplicate column name 'use_existing'
[2020-10-24 21:49:21] (Flux_Error) **TRACE** #0 D:\Instalados\xampp\htdocs\RagnaForest\lib\Flux\Installer\Schema.php(155): Flux_Installer_Schema->install(20081109093448)
[2020-10-24 21:49:21] (Flux_Error) **TRACE** #1 D:\Instalados\xampp\htdocs\RagnaForest\lib\Flux\Installer.php(75): Flux_Installer_Schema->update()
[2020-10-24 21:49:21] (Flux_Error) **TRACE** #2 D:\Instalados\xampp\htdocs\RagnaForest\modules\install\index.php(31): Flux_Installer->updateAll()
[2020-10-24 21:49:21] (Flux_Error) **TRACE** #3 D:\Instalados\xampp\htdocs\RagnaForest\lib\Flux\Template.php(375): include('D:\\Instalados\\x...')
[2020-10-24 21:49:21] (Flux_Error) **TRACE** #4 D:\Instalados\xampp\htdocs\RagnaForest\lib\Flux\Dispatcher.php(170): Flux_Template->render()
[2020-10-24 21:49:21] (Flux_Error) **TRACE** #5 D:\Instalados\xampp\htdocs\RagnaForest\index.php(169): Flux_Dispatcher->dispatch(Array)
[2020-10-24 21:49:21] (Flux_Error) **TRACE** #6 {main}
