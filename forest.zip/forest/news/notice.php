<?php foreach($rss->items as $item):?>
<h4><a class="news_link" href="<?php echo $item['link'] ?>" target="_blank"><?php echo $item['title'] ?></a>
     <?php if(isset($item['pubdate'])): ?>
         <small>on <?php $item['pubdate'] = date ('l, F dS, Y', strtotime ($item['pubdate'])); echo $item['pubdate'];?></small>
     <?php endif; ?>
</h4>
<hr/>
<?php endforeach; ?>