<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>Newbie Guide</h2>
<p class="note">Please write contents inside <?php echo htmlspecialchars(__FILE__) ?></p>