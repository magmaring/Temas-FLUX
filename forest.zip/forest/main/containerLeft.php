<?php if (!defined('FLUX_ROOT')) exit;

if($params->get('action')=='login') {
	$pvpladder = array();
} else {
	$sqlpvp = "SELECT `pvpladder`.`kills`, `pvpladder`.`streaks`, `pvpladder`.`deaths`, `char`.`name`, `char`.`class`, `char`.`base_level`, `char`.`job_level`, `char`.`account_id`, `char`.`online`, `login`.`sex` FROM `pvpladder` LEFT JOIN `char` ON `char`.`char_id` = `pvpladder`.`char_id` LEFT JOIN `login` ON `login`.`account_id` = `char`.`account_id` WHERE `login`.`state` = '0' ORDER BY `pvpladder`.`kills` DESC, `pvpladder`.`streaks` DESC, `pvpladder`.`deaths` DESC, `char`.`base_exp` DESC LIMIT 0,5"; 
	$sthpvp = $server->connection->getStatement($sqlpvp);
	$sthpvp->execute();
	$pvpladder = $sthpvp->fetchAll();
}
?>
<div class="containerLeft">
	<div class="left-navigation">
		<ul class="no-list">
			<li><a href="<?php echo $this->url('account','create'); ?>">Register<span>create account</span></a></li>
			<li><a href="<?php echo $this->url('main','download'); ?>">Download<span>game client</span></a></li>
			<li><a href="<?php echo $this->url('purchase'); ?>">Item Mall<span>good stuffs</span></a></li>
			<li><a class="fb-share" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo Flux::config('ServerAddress'); ?>">Share<br/>This Site<span>tell a friend</span></a></li>
		</ul>
	</div>
	<div class="database-search">
		<form action="">
			<input type="hidden" name="module" value="item">
			<input type="text" name="name">
			<input type="submit">
			<div class="select-db">
				<a href="item" class="active"><img src="<?php echo $this->themePath('img/search-tab.png'); ?>" alt=""></a>
				<a href="monster"><img src="<?php echo $this->themePath('img/search-tab.png'); ?>" alt=""></a>
			</div>
		</form>
	</div>
	<div class="pvp-rankings">
		<table>
			<?php if(!empty($pvpladder)): ?>
				<?php $i=1; foreach ($pvpladder as $pvpplayer): ?>
				<tr>
					<td width="15"><?php echo $i++; ?></td>
					<td width="105"><?php echo ((strlen($pvpplayer->name)>21)? substr($pvpplayer->name, 0,21)."..":$pvpplayer->name); ?></td>
					<td><?php echo number_format($pvpplayer->kills); ?></td>
				</tr>
				<?php endforeach; ?>
			<?php endif; ?>
		</table>
	</div>
</div>