<?php
return array(

	// Buttons
		'play_android'	=>	'http://google.com',
		'pc_download'	=>	'http://google.com',
		'ro_browser'	=>	'https://www.robrowser.com/',

	// Server Time
		'server_time'	=>	'<iframe src="http://free.timeanddate.com/clock/i5pl7h48/n233/fce7debd/tct/pct" frameborder="0" width="116" height="18" allowTransparency="true"></iframe>',

	// Youtube video
		'youtube-video'		=>	'<iframe width="560" height="315" src="https://www.youtube.com/embed/GFoyePOkQz4" frameborder="0" allowfullscreen></iframe>',

	// Rate my server link
		'rms' 			=> 	'http://ratemyserver.net',
		
	// Social page links
		'facebook'		=>	'https://www.facebook.com/ragnastarts',
		'discord'		=>	'https://discordapp.com/',
		'youtube'		=>	'http://youtube.com',
		
	// Forums link here
		'forum' 		=> 	'http://ragnastart.net/forum',
		
	// RSS settings
		'enablerss'		=> 	true,						// true/ false	true will show RSS links on index page
		'news' 			=> 	'http://ragnastart.net/forum/index.php?/forum/8-informa%C3%A7%C3%B5es-gerais.xml',		// RSS News link
		'updates'		=> 	'http://ragnastart.net/forum/index.php?/forum/7-atualiza%C3%A7%C3%B5es-e-change-logs.xml',		// RSS News link
		'events'		=> 	'http://ragnastart.net/forum/index.php?/forum/6-eventos-e-promo%C3%A7%C3%B5es.xml/',		// RSS News link

	// slides	
		'slides' => array(
			'slide.png',
			'slide.png',
			'slide.png',
			'slide.png',
		),

	// featured_items ( Upload image inside themes/default/img folder )
		'featured_items' => array(
			// Item name, image.ext, Purchase points
			'Aegir Armor, 15138.gif, 20 Kafra Points',
			'Angelic Protection, 2358.gif, 8 Credits',
			'Aqua Robe, 15026.gif, 5 Cash Points',
		),

	// Woe Schedule
		'woe_schd'		=>	array(
			// Castle name, day time ( 24 hours format )
			'Kriemhield, friday 20:00:00',
			'Britoniah Guild, saturday 12:00:00',
			'Greenwood Lake, sunday 10:00:00',
		),
	)
?>