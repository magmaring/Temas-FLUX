<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>Server Features</h2>
<p class="note">Please write contents inside <?php echo htmlspecialchars(__FILE__) ?></p>