<?php if (!defined('FLUX_ROOT')) exit;

if( $EADev['enablerss'] ) 
	include 'rsslib.php'; 
?>
<div class="indexPage">
	<div class="slider">
		<div class="slider-pager"></div>
		<div class="slides cycle-slideshow" data-cycle-fx="scrollHorz" data-cycle-timeout="2000" data-cycle-pager=".slider-pager"> 
			<?php foreach ($EADev['slides'] as $slide): ?>
				<img src="<?php echo $this->themePath('img/'.$slide); ?>" alt="">
			<?php endforeach; ?>
		</div>
	</div>
	<div class="featured-item">
		<div class="featured-items">
			<div class="cycle-slideshow" data-cycle-fx="carousel" data-cycle-timeout="1000">
				<?php foreach ($EADev['featured_items'] as $f_item): $e_fitem = explode(",", $f_item); ?>
					<img src="<?php echo $this->themePath('img/'. trim($e_fitem[1])); ?>" alt="" title="<?php echo $e_fitem[0]; ?><br/>Cost: <?php echo $e_fitem[2]; ?>">
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<div class="welcome">
		<div class="video">
			<?php echo $EADev['youtube-video']; ?>
		</div>
		<div class="welcomeText">
			<h2>Welcome</h2>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum
			</p>
		</div>
	</div>
	<div class="news-section">
		<div class="news">
			<div class="tab">
				<div class="tab-links">
					<ul>
						<li><a class="active" href="#all">All</a></li> 
						<li><a href="#news">News</a></li>
						<li><a href="#updates">Updates</a></li>
						<li><a href="#events">Events</a></li>
					</ul>
				</div>
				<div class="tab-content">
					<div id="all">
						<?php if( $EADev['enablerss'] ): ?>
							<?php echo RSS_Display(array('news' => $EADev['news'], 'updates' => $EADev['updates'], 'events' => $EADev['events']), 7); ?>
						<?php endif; ?>
					</div>
					<div class="hidden" id="news">
						<?php if( $EADev['enablerss'] ): ?>
							<?php echo RSS_Display(array('news' => $EADev['news']), 7); ?>
						<?php endif; ?>
					</div>
					<div class="hidden" id="updates">
						<?php if( $EADev['enablerss'] ): ?>
							<?php echo RSS_Display(array('updates' => $EADev['news']), 7); ?>
						<?php endif; ?>
					</div>
					<div class="hidden" id="events">
						<?php if( $EADev['enablerss'] ): ?>
							<?php echo RSS_Display(array('events' => $EADev['news']), 7); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>