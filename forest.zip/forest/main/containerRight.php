<?php if (!defined('FLUX_ROOT')) exit;
	
	$index=0; 
	$woe_schd = $woe_castles = array();
	foreach ($EADev['woe_schd'] as $woeschd) {
		$e_woe_schd = explode(",", $woeschd);
		$woe_castles[] = $e_woe_schd[0];
		$woe_schd[] = $e_woe_schd[1];
	}
	foreach($woe_schd as $key => $woe):
		if( strtotime($woe_schd[0]) > strtotime($woe) ):
			$index = $key;
		endif;
	endforeach;

	if($params->get('action') == 'login') {
		$hofguilds = array();
	} else {

		$sqlgvg  = "SELECT g.guild_id, g.name AS gname, g.emblem_len, (SELECT COUNT( c.castle_id ) FROM guild_castle c WHERE c.guild_id = g.guild_id ) AS castles, g.master, (SELECT COUNT( char_id ) FROM  `char` WHERE  `char`.guild_id = g.guild_id ) AS members FROM guild AS g LEFT JOIN  `char` AS ch ON ch.char_id = g.char_id LEFT JOIN login ON login.account_id = ch.account_id ORDER BY castles DESC, members DESC , g.max_member DESC , g.next_exp ASC LIMIT 1"; 
		$sthgvg  = $server->connection->getstatement($sqlgvg);
		$sthgvg->execute();
		$hofguilds = $sthgvg->fetch();
	}

?>
<div class="containerRight">
	<?php include 'loginpanel.php'; ?>
	<div class="woe-block">
		<div class="next-woe">
			<div class="woe_countdown">
				<?php echo date('M d, Y H:i:s', strtotime($woe_schd[$index])); ?>
			</div>
			<div class="castle-name"><?php echo $woe_castles[$index]; ?></div>
		</div>
		<div class="top-castle">
			<?php if(!empty($hofguilds)): ?>
			<img src="<?php echo $this->emblem($hofguilds->guild_id); ?>" title="<?php echo $hofguilds->gname; ?><br/>Master: <?php echo $hofguilds->master; ?><br/>Castles: <?php echo $hofguilds->castles; ?>" alt="">
			<?php endif; ?>
		</div>
		<div class="guild-buttons">
			<a href="<?php echo $this->url('ranking','guild'); ?>"><img src="<?php echo $this->themePath('img/guild-btns.png'); ?>" alt=""></a>
			<a href="<?php echo $this->url('main','discussion'); ?>"><img src="<?php echo $this->themePath('img/guild-btns.png'); ?>" alt=""></a>
		</div>
	</div>
	<div class="quicklinks">
		<ul class="no-list">
			<li><a href="<?php echo $this->url('vote'); ?>"><img src="<?php echo $this->themePath('img/quicklink-btn.png'); ?>" alt=""></a></li>
			<li><a href="<?php echo $EADev['rms']; ?>" target="_blank"><img src="<?php echo $this->themePath('img/quicklink-btn.png'); ?>" alt=""></a></li>
			<li><a href="<?php echo $this->url('main','newbie'); ?>"><img src="<?php echo $this->themePath('img/quicklink-btn.png'); ?>" alt=""></a></li>
		</ul>
	</div>
</div>