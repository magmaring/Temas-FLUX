<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>Support</h2>
<p class="note">Please write contents inside <?php echo htmlspecialchars(__FILE__) ?></p>