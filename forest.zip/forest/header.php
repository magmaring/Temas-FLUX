<?php if (!defined('FLUX_ROOT')) exit; ?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<?php if (isset($metaRefresh)): ?>
		<meta http-equiv="refresh" content="<?php echo $metaRefresh['seconds'] ?>; URL=<?php echo $metaRefresh['location'] ?>" />
		<?php endif ?>
		<title><?php echo Flux::config('SiteTitle'); if (isset($title)) echo ": $title" ?></title>
		<link rel="stylesheet" href="<?php echo $this->themePath('css/flux.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $this->themePath('css/style.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<link href="<?php echo $this->themePath('css/flux/unitip.css') ?>" rel="stylesheet" type="text/css" media="screen" title="" charset="utf-8" />
		<?php if (Flux::config('EnableReCaptcha')): ?>
		<link href="<?php echo $this->themePath('css/flux/recaptcha.css') ?>" rel="stylesheet" type="text/css" media="screen" title="" charset="utf-8" />
		<?php endif ?>
		<script type="text/javascript" src="<?php echo $this->themePath('js/jquery-1.8.3.min.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/flux.datefields.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/flux.unitip.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/eadev.js') ?>"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.money-input').keyup(function() {
					var creditValue = parseInt($(this).val() / <?php echo Flux::config('CreditExchangeRate') ?>, 10);
					if (isNaN(creditValue))
						$('.credit-input').val('?');
					else
						$('.credit-input').val(creditValue);
				}).keyup();
				$('.credit-input').keyup(function() {
					var moneyValue = parseFloat($(this).val() * <?php echo Flux::config('CreditExchangeRate') ?>);
					if (isNaN(moneyValue))
						$('.money-input').val('?');
					else
						$('.money-input').val(moneyValue.toFixed(2));
				}).keyup();
				processDateFields();
			});
			function reload(){
				window.location.href = '<?php echo $this->url ?>';
			}
		</script>
		<script type="text/javascript">
			function updatePreferredServer(sel){
				var preferred = sel.options[sel.selectedIndex].value;
				document.preferred_server_form.preferred_server.value = preferred;
				document.preferred_server_form.submit();
			}
			function updatePreferredTheme(sel){
				var preferred = sel.options[sel.selectedIndex].value;
				document.preferred_theme_form.preferred_theme.value = preferred;
				document.preferred_theme_form.submit();
			}
			var spinner = new Image();
			spinner.src = '<?php echo $this->themePath('img/spinner.gif') ?>';
			function refreshSecurityCode(imgSelector){
				$(imgSelector).attr('src', spinner.src);
				var clean = <?php echo Flux::config('UseCleanUrls') ? 'true' : 'false' ?>;
				var image = new Image();
				image.src = "<?php echo $this->url('captcha') ?>"+(clean ? '?nocache=' : '&nocache=')+Math.random();
				$(imgSelector).attr('src', image.src);
			}
			function toggleSearchForm()
			{
				$('.search-form').slideToggle('fast');
			}
		</script>
		<?php if (Flux::config('EnableReCaptcha')): ?>
			<script src='https://www.google.com/recaptcha/api.js'></script>
		<?php endif ?>
	</head>
	<body>
		<?php $EADev = include 'main/EADevConfig.php'; ?>
		<div class="social-icons">
			<ul class="no-list">
				<li><a href="<?php echo $EADev['facebook']; ?>"><img src="<?php echo $this->themePath('img/social-icon.png'); ?>" alt=""></a></li>
				<li><a href="<?php echo $EADev['discord']; ?>"><img src="<?php echo $this->themePath('img/social-icon.png'); ?>" alt=""></a></li>
				<li><a href="<?php echo $EADev['youtube']; ?>"><img src="<?php echo $this->themePath('img/social-icon.png'); ?>" alt=""></a></li>
			</ul>
		</div>
		<div id="wrapper">
			 <div class="header">
				<?php include 'main/status.php'; ?>
				<a href="<?php echo $this->url('main'); ?>" class="logo"><img src="<?php echo $this->themePath('img/logo.png'); ?>" alt=""></a>
			</div>
			<div class="container">
				<?php include 'main/containerLeft.php'; ?>
				<div class="containerMiddle">
					<div class="content">
						<div class="contentTop">
							<div class="navigation">
								<ul class="no-list">
									<li><a href="<?php echo $this->url('main'); ?>"><img src="<?php echo $this->themePath('img/nav.png'); ?>" alt=""></a></li>
									<li><a href="<?php echo $EADev['forum']; ?>" target="_blank"><img src="<?php echo $this->themePath('img/nav.png'); ?>" alt=""></a></li>
									<li><a href="<?php echo $this->url('main','support'); ?>"><img src="<?php echo $this->themePath('img/nav.png'); ?>" alt=""></a></li>
									<li><a href="<?php echo $this->url('service','tos'); ?>"><img src="<?php echo $this->themePath('img/nav.png'); ?>" alt=""></a></li>
									<li><a href="<?php echo $this->url('main','features'); ?>"><img src="<?php echo $this->themePath('img/nav.png'); ?>" alt=""></a></li>
									<li><a href="<?php echo $this->url('ranking','character'); ?>"><img src="<?php echo $this->themePath('img/nav.png'); ?>" alt=""></a></li>
									<li><a href="<?php echo $this->url('donate'); ?>"><img src="<?php echo $this->themePath('img/nav.png'); ?>" alt=""></a></li>
								</ul>
							</div>
						</div>
						<div class="contentInner <?php echo $_thisModule . $_thisAction; ?>">
							<div class="message_nav">
								<?php if ($message=$session->getMessage()): ?>
									<p class="message"><?php echo htmlspecialchars($message) ?></p>
								<?php endif ?>
								<?php include $this->themePath('main/submenu.php', true); ?>
								<?php include $this->themePath('main/pagemenu.php', true); ?>
								<?php if (in_array($params->get('module'), array('donate', 'purchase'))) include $this->themePath('main/balance.php', true); ?>
							</div>
							<div class="contentBox <?php echo $_thisModule . $_thisAction; ?>">
