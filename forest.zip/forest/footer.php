<?php if (!defined('FLUX_ROOT')) exit; ?>
							</div>
						</div> <!-- contentInner -->
						<div class="contentBottom"></div>
					</div> <!-- content -->
				</div> <!-- containerMiddle -->
				<?php include 'main/containerRight.php'; ?>
			</div> <!-- container -->
			<div class="footer">
				<div class="container">
					<div class="copyrights">
						&copy; Copyright <?php echo date('Y'); ?>. All Registered Trademarks belong to their 
						Respective Owners.<br/>Website Design/Coded by <a href="http://ea-dev.com" target="_blank">EADev</a>.
					</div>
					<div class="credits">
						<a href="http://ea-dev.com" target="_blank"><img src="<?php echo $this->themePath('img/eadev.png'); ?>" alt=""></a>
						<a href="http://renncgfx.com" target="_blank"><img src="<?php echo $this->themePath('img/rennc.png'); ?>" alt=""></a>
					</div>
				</div>
			</div>
		</div> <!-- wrapper -->
	</body>
</html>
