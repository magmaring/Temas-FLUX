<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2> <?php echo htmlspecialchars(Flux::message('ResetPassTitle')) ?> </h2>
<?php if (!empty($errorMessage)): ?>
<p class="red"><?php echo htmlspecialchars($errorMessage) ?></p>
<?php endif ?>
<p><?php echo htmlspecialchars(Flux::message('ResetPassInfo')) ?></p>
<p><?php echo htmlspecialchars(Flux::message('ResetPassInfo2')) ?></p>
<form action="<?php echo $this->urlWithQs ?>" method="post" class="generic-form form-horizontal">
	<table class="generic-form-table">
		<?php if (count($serverNames) > 1): ?>
		<tr>
			<th><label for="login"><?php echo htmlspecialchars(Flux::message('ResetPassServerLabel')) ?></label></th>
			<td>
				<select name="login" id="login"<?php if (count($serverNames) === 1) echo ' disabled="disabled"' ?>>
				<?php foreach ($serverNames as $serverName): ?>
					<option value="<?php echo htmlspecialchars($serverName) ?>"<?php if ($params->get('server') == $serverName) echo ' selected="selected"' ?>><?php echo htmlspecialchars($serverName) ?></option>
				<?php endforeach ?>
				</select>
			</td>
			<td><p><?php echo htmlspecialchars(Flux::message('ResetPassServerInfo')) ?></p></td>
		</tr>
		<?php endif ?>
		<tr>
			<td>
				<div class="form-group">
					<label for="userid" class="control-label col-md-4"><?php echo htmlspecialchars(Flux::message('ResetPassAccountLabel')) ?></label>
					<div class="col-md-8">
						<input type="text" class="form-control" name="userid" id="userid" />
						<p><?php echo htmlspecialchars(Flux::message('ResetPassAccountInfo')) ?></p>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="form-group">
					<label for="email" class="control-label col-md-4"><?php echo htmlspecialchars(Flux::message('ResetPassEmailLabel')) ?></label>
					<div class="col-md-8">
						<input type="text" class="form-control" name="email" id="email" />
						<p><?php echo htmlspecialchars(Flux::message('ResetPassEmailInfo')) ?></p>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="form-group">
					<label for="email" class="control-label col-md-4"></label>
					<div class="col-md-8">
						<button type="submit" class="btn btn-btn btn-block" value=" "><?php echo htmlspecialchars(Flux::message('ResetPassButton')) ?></button>
					</div>
				</div>
			</td>
		</tr>
	</table>
</form>