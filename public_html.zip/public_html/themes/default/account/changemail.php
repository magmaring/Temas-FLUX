<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2><?php echo htmlspecialchars(Flux::message('EmailChangeHeading')) ?></h2>

<?php if (!empty($errorMessage)): ?>
<p class="red"><?php echo htmlspecialchars($errorMessage) ?></p>
<?php endif ?>

<p><?php echo htmlspecialchars(Flux::message('EmailChangeInfo')) ?></p>

<?php if (Flux::config('RequireChangeConfirm')): ?>
<p><?php echo htmlspecialchars(Flux::message('EmailChangeInfo2')) ?></p>
<?php endif ?>

<form action="<?php echo $this->urlWithQs ?>" method="post" class="generic-form form-horizontal">
	<table class="generic-form-table">
		<tr>
			<td>
				<div class="form-group">
					<label for="email" class="control-label col-md-4"><?php echo htmlspecialchars(Flux::message('EmailChangeLabel')) ?></label>
					<div class="col-md-8">
						<input class="form-control" type="text" name="email" id="email" />
						<p><?php echo htmlspecialchars(Flux::message('EmailChangeInputNote')) ?></p>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<div class="form-group">
					<div class="col-md-4"></div>
					<div class="col-md-8">
						<button class="btn btn-btn btn-block" type="submit" value=" "><?php echo htmlspecialchars(Flux::message('EmailChangeButton')) ?></button>
					</div>
				</div>
			</td>
		</tr>
	</table>
</form>