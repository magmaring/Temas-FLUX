<?php if (!defined('FLUX_ROOT')) exit; ?>
<style type="text/css">
#easyTooltip{
	width:;
	text-align:left;
	padding-left: 5px;
	padding-right: 5px;
	padding-top:6px;
	border:1px solid #7e934c;
	background:#8daf3b;
	color:#fff;
	font: 11px tahoma;
height: 20px;
}

table.infos { margin-left:20px; font: 11px tahoma; }
span.destaque1 { color:#0588C7; }

table.infos2 { font: bold 11px tahoma; text-align:left;}
table.infos2 tr td { border:1px solid #FFF; }
table.infos2 tr td:hover { border:1px solid #FFF; background:#444; color:#FFF;}
span.color { color:#0588C7; }
#resposta {
cursor: pointer; /*IE*/
cursor: hand; /*FF e demais*/
width: 80%;
margin:0 auto;
margin-left:12px;
}

#resposta:hover { color:#FFF; }
.passe { float:right; font: 11px tahoma; }

span.titulos-paginas { font: 31px gill, ikeda, tahoma; color:#C33; }
#divhover {  color:#666; }
#divhover:hover { background:#444; color:#FFF; }

#divhover2 { text-align:center; width:221px; color:#666; }
#divhover2:hover { background:#444; color:#FFF; }
</style><div id="content-principal">
<div style="height:4px;"></div>
<div style="margin:0 auto; text-align:center; width:95%;"> <!-- margem conteudo -->
<div style="margin:0 auto; text-align:center;height:40px;">
<span class="titulos-paginas">Informa&ccedil;&otilde;es do Servidor</span>
</div><!-- titulo div -->
<div style="height:10px;"></div>


<div style="float:left; width:32%; height:; background:#F8F8F8;">

<div id="divhover" style=" padding-left:20px; padding-top:10px; text-align:left; font: 16px ikeda, tahoma; height:30px; border:1px solid #fff;"><span style="color:#94BB1C;">Informa&ccedil;&otilde;es b&aacute;sicas</span></div>

<div id="divhover" style=" padding-left:20px; padding-top:10px; text-align:left; font: 13px ikeda, tahoma; height:28px; border:1px solid #fff;">Level M&aacute;ximo 300</div>

<div id="divhover" style=" padding-left:20px; padding-top:10px; text-align:left; font: 13px ikeda, tahoma; height:28px; border:1px solid #fff;">Nivel maximo de base 200</div>

<div id="divhover" style=" padding-left:20px; padding-top:10px; text-align:left; font: 13px ikeda, tahoma; height:28px; border:1px solid #fff;"> Drops de Itens: 100%</div>

<div id="divhover" style=" padding-left:20px; padding-top:10px; text-align:left; font: 13px ikeda, tahoma; height:28px; border:1px solid #fff;">Drops de Cartas Mvp e mínimos 1%</div>

<div id="divhover" style=" padding-left:20px; padding-top:10px; text-align:left; font: 13px ikeda, tahoma; height:28px; border:1px solid #fff;">Drops de cartas normais 15%</div>

<div id="divhover" style=" padding-left:20px; padding-top:10px; text-align:left; font: 13px ikeda, tahoma; height:28px; border:1px solid #fff;">Rates Gerais: Normal rate !
Exp 15k 15k </div>

<div id="divhover" style=" padding-left:20px; padding-top:10px; text-align:left; font: 13px ikeda, tahoma; height:28px; border:1px solid #fff;">ASPD 196</div>

<div id="divhover" style=" padding-left:20px; padding-top:15px; text-align:left; font: 13px ikeda, tahoma; height:30px; border:1px solid #fff;">+50 Quests Ativa</div>


</div>

<div style="float:left; width:6px; height:50px;"></div>
<div style="float:left; width:67%; height:; text-align:center; background:#F8F8F8;">

<table width="100%" height="200px" border="0" cellspacing="0" cellpadding="0" class="infos2">
  <tr>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Teleporta o personagem para qualquer cidade."><span class="color">@</span>go</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Mostra informa&ccedil;&otilde;es de qualquer monstro."><span class="color">@</span>buff</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Mostra informa&ccedil;&otilde;es de qualquer item."><span class="color">@</span>iteminfo</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Protege contra KS em monstros."><span class="color">@</span>noks</div></td>
  </tr>
  <tr>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Mostra todas as Rates do Servidor. "><span class="color">@</span>rates</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Abre o armaz&eacute;m. "><span class="color">@</span>storage</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Pega itens dropados diretos em seu invent&aacute;rio. "><span class="color">@</span>autoloot</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Deixa o personagem vendendo mesmo offline."><span class="color">@</span>autotrade</td>
  </tr>
  <tr>
	 <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Teleporta o personagem para qualquer cidade."><span class="color">@</span>warp</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Mostra informa&ccedil;&otilde;es ao matar algu&eacute;m ou morrer em BG/WoE "><span class="color">@</span>battleinfo</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;"  title="Abre sua caixa de e-mail"><span class="color">@</span>mail</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Mostra a hora no Servidor. "><span class="color">@</span>time</div></td>
  </tr>
  <tr>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;"  title="Convida um advers&aacute;rio para duelo. "><span class="color">@</span>invite</div></td>
    <td><div id="resposta"  style=" padding-left:50px; padding-top:10px;" title="Aceita convite de duelo. "><span class="color">@</span>accept</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;"  title="Rejeita convite de duelo. "><span class="color">@</span>reject</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;"  title="Desiste de um duelo. "><span class="color">@</span>leave</div></td>
  </tr>
  <tr>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;"  title="Mostra quais monstros dropam o item. "><span class="color">@</span>whodrops</div></td>
	<td><div id="resposta" style=" padding-left:50px; padding-top:10px;"  title="Mostra sua quantidade de experi&ecirc;ncia. "><span class="color">@</span>exp</div></td>
 	<td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Mostra em qual ponto do mapa est&aacute; o monstro (exceto chefes)."><span class="color">@</span>showmobs [VIP]</div></td>
 	<td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Mostra os mapas onde habitam os monstros."><span class="color">@</span>whereis [VIP]</div></td>
  </tr>
  <tr>	
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;"  title="Convida um advers&aacute;rio para duelo. "><span class="color">@</span>duel</div></td>
    <td><div id="resposta"  style=" padding-left:50px; padding-top:10px;" title="Lista de todos os comandos dispon&iacute;vel. "><span class="color">@</span>commands</div></td>
    <td><div id="resposta"  style=" padding-left:50px; padding-top:10px;" title="Mostra o tempo de recarga das habilidades. "><span class="color">@</span>showdelay</div></td>
    <td><div id="resposta"  style=" padding-left:50px; padding-top:10px;" title="Mostra experi&ecirc;ncia ao matar monstros . "><span class="color">@</span>showexp</div></td>
  </tr>
 <tr>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Teleporta o personagem para sala VIP."><span class="color">@</span>govip [VIP]</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Liga autoloot somente de um item espec&iacute;fico."><span class="color">@</span>alootid [VIP]</div></td>
    <td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Troca o l&iacute;der do cl&atilde;."><span class="color">@</span>changegm [VIP]</div></td>
	<td><div id="resposta" style=" padding-left:50px; padding-top:10px;" title="Mostra status do seu homunculus."><span class="color">@</span>homstats [VIP]</div></td>
	</tr>

</table>

</div>


</div> <!-- margem conteudo -->
<div style="clear:both;"></div></div>
