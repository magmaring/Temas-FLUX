<?php if (!defined('FLUX_ROOT')) exit; 
$title = Flux::message('ServerStatusTitle');
$cache = FLUX_DATA_DIR.'/tmp/ServerStatus.cache';

if (file_exists($cache) && (time() - filemtime($cache)) < (Flux::config('ServerStatusCache') * 60)) {
	$serverStatus = unserialize(file_get_contents($cache));
}
else {
	$serverStatus = array();
	foreach (Flux::$loginAthenaGroupRegistry as $groupName => $loginAthenaGroup) {
		if (!array_key_exists($groupName, $serverStatus)) {
			$serverStatus[$groupName] = array();
		}

		$loginServerUp = $loginAthenaGroup->loginServer->isUp();

		foreach ($loginAthenaGroup->athenaServers as $athenaServer) {
			$serverName = $athenaServer->serverName;

			$sql = "SELECT COUNT(char_id) AS players_online FROM {$athenaServer->charMapDatabase}.char WHERE online > 0";
			$sth = $loginAthenaGroup->connection->getStatement($sql);
			$sth->execute();
			$res = $sth->fetch();

			$serverStatus[$groupName][$serverName] = array(
				'loginServerUp'     => $loginServerUp,
				'charServerUp'      => $athenaServer->charServer->isUp(),
				'mapServerUp'       => $athenaServer->mapServer->isUp(),
				'playersOnline'     => intval($res ? $res->players_online : 0),
			);
		}
	}
	
	$fp = fopen($cache, 'w');
	if (is_resource($fp)) {
		fwrite($fp, serialize($serverStatus));
		fclose($fp);
	}
}
?> 

<?php 
	$online = '<span class="online">ONLINE</span>';
	$offline = '<span class="offline">OFFLINE</span>';
	foreach ($serverStatus as $privServerName => $gameServers):
		foreach ($gameServers as $serverName => $gameServer):
		if ($gameServer['loginServerUp']) { $loginserver = 1; } else { $loginserver = 0; } 
		if ($gameServer['charServerUp']) { $charserver = 1; } else { $charserver = 0; } 
		if ($gameServer['mapServerUp']) { $mapserver = 1; } else { $mapserver = 0; } 
		$online_player = $gameServer['playersOnline'];
		endforeach; 
	endforeach; 
?>
<div class="online-status">
	SERVER: <?php echo ($mapserver)? $online:ONLINE; ?>
</div>
<div class="players-online">
	PLAYERS: <span class="online"><?=$online_player;?></span>
</div>