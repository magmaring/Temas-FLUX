<?php if (!defined('FLUX_ROOT')) exit; ?>
<style type="text/css">

body,td,th {
	color: #000000;
}
</style>
<center>
<h2>Downloads</h2>
<p><img src="themes/default/img/down.png" width="91" height="64" alt=""/></p>
<h2>Direct Link</h2>
<h2><a href="http://www.mediafire.com/file/xslmdbw1l63o4s1/roxro_1v1.rar/file"><img src="themes/default/img/logo.png" width="232" height="138" alt=""/></a></h2>
<h5>Patch sem data.grf</h5>
<h4>Use a data do Bro</h4>
<p>&nbsp;</p>
</center>
<center>
<h2>Link MediaFire</h2>
<h2><a href="http://www.mediafire.com/file/xslmdbw1l63o4s1/roxro_1v1.rar/file"><img src="themes/default/img/mediafire1.png" width="232" height="138" alt=""/></a></h2>
<p>&nbsp;</p>
</center>
