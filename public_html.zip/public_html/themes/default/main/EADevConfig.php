<?php
return array(

	// Links
		'facebook'		=>	'https://www.facebook.com/Roxrooo',
		'twitter'		=>	'https://twitter.com',
		'youtube'		=>	'https://youtube.com',
		'instagram'		=>	'https://www.instagram.com/roxro21/?hl=pt-br',
		'forum'			=>	'http://forum.com',

	// RSS settings
		'enablerss'		=> 	true,			// true/ false	true will show RSS links on index page
		'news' 			=> 	'http://ea-dev.com/prev/rss.xml',		// RSS News link
		'events'		=> 	'http://ea-dev.com/prev/rss.xml',		// RSS News link
		'updates'		=> 	'http://ea-dev.com/prev/rss.xml',		// RSS News link

	// Castles Ranks and WoE Timings
		'castles'		=>	array(
			15	=>	'05:00 - 06:00',
			16	=>	'05:00 - 06:00',
			17	=>	'05:00 - 06:00',
		),

)
?>