<?php exit('Forbidden'); ?>
[2020-06-13 19:54:18] sent e-mail -- Recipient: gilma_cocoia@hotmail.com, Subject: Reset Password
[2020-06-13 19:55:49] sent e-mail -- Recipient: gilma_cocoia@hotmail.com, Subject: Reset Password
