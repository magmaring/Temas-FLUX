<?php exit('Forbidden'); ?>
[2020-05-28 00:30:16] sent e-mail -- Recipient: everton827@gmail.com, Subject: Reset Password
[2020-05-28 00:32:39] sent e-mail -- Recipient: everton827@gmail.com, Subject: Password Has Been Reset
