<?php exit('Forbidden'); ?>
[2020-05-26 13:09:51] sent e-mail -- Recipient: esdras_master@hotmail.com, Subject: Reset Password
[2020-05-26 13:10:06] sent e-mail -- Recipient: esdras_master@hotmail.com, Subject: Reset Password
[2020-05-26 13:11:11] sent e-mail -- Recipient: esdras_master@hotmail.com, Subject: Password Has Been Reset
[2020-05-26 13:11:11] sent e-mail -- Recipient: esdras_master@hotmail.com, Subject: Password Has Been Reset
