<?php exit('Forbidden'); ?>
[2020-06-21 21:44:14] sent e-mail -- Recipient: ananias.s.barreto@gmail.com, Subject: Reset Password
[2020-06-21 21:44:22] sent e-mail -- Recipient: ananias.s.barreto@gmail.com, Subject: Reset Password
[2020-06-21 21:46:09] sent e-mail -- Recipient: ananias.s.barreto@gmail.com, Subject: Reset Password
