<?php exit('Forbidden'); ?>
[2020-06-19 22:08:47] sent e-mail -- Recipient: edrickvenceslau@hotmail.com, Subject: Reset Password
[2020-06-19 22:13:48] sent e-mail -- Recipient: edrickvenceslau@hotmail.com, Subject: Reset Password
