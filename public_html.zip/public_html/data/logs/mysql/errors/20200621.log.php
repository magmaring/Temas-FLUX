<?php exit('Forbidden'); ?>
[2020-06-21 15:56:40] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-21 15:56:40] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-06-21 18:17:36] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-21 18:17:36] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-06-21 22:24:19] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-21 22:24:19] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-06-21 22:24:56] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-21 22:24:56] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-06-21 22:25:10] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-21 22:25:10] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-06-21 23:53:32] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.mob_db' doesn't exist
[2020-06-21 23:53:32] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.monsters' doesn't exist
[2020-06-21 23:53:32] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.monsters' doesn't exist
