<?php exit('Forbidden'); ?>
[2020-05-30 12:34:22] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-05-30 12:34:22] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-05-30 15:11:16] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-05-30 15:11:17] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-05-30 15:51:58] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-05-30 15:51:59] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-05-30 20:52:09] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-05-30 20:52:09] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-05-30 22:26:23] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-05-30 22:26:23] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-05-30 22:26:28] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-05-30 22:26:29] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
