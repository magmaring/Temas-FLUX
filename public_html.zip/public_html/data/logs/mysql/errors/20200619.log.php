<?php exit('Forbidden'); ?>
[2020-06-19 05:09:09] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-19 05:09:09] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
