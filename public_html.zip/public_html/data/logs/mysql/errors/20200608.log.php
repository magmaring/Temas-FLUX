<?php exit('Forbidden'); ?>
[2020-06-08 00:38:02] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.mob_db' doesn't exist
[2020-06-08 00:38:02] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.monsters' doesn't exist
[2020-06-08 00:38:02] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.monsters' doesn't exist
[2020-06-08 03:23:47] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-08 03:23:47] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-06-08 14:53:34] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-08 14:53:34] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-06-08 15:15:55] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-08 15:15:55] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-06-08 15:21:20] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-08 15:21:20] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
