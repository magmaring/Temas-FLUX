<?php exit('Forbidden'); ?>
[2020-06-07 02:51:35] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.mob_db' doesn't exist
[2020-06-07 02:51:35] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.monsters' doesn't exist
[2020-06-07 02:51:35] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.monsters' doesn't exist
[2020-06-07 05:23:05] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.mob_db' doesn't exist
[2020-06-07 05:23:05] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.monsters' doesn't exist
[2020-06-07 05:23:05] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.monsters' doesn't exist
[2020-06-07 18:56:38] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-07 18:56:38] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
