<?php exit('Forbidden'); ?>
[2020-05-24 10:47:03] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-05-24 10:47:04] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-05-24 10:47:47] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-05-24 10:47:47] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
