<?php exit('Forbidden'); ?>
[2020-06-22 00:04:10] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-22 00:04:10] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-06-22 14:04:59] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-22 14:04:59] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
[2020-06-22 19:14:30] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.item_db' doesn't exist
[2020-06-22 19:14:30] [SQLSTATE=42S02] Err 1146: Table 'rlcpw9f5_ragnarok.items' doesn't exist
