<?php exit('Forbidden'); ?>
[2020-05-03 13:07:09] (PDOException) Exception PDOException: SQLSTATE[HY000] [1130] Host 'ip169.ip-54-39-44.net' is not allowed to connect to this MySQL server
[2020-05-03 13:07:09] (PDOException) **TRACE** #0 /home/fantasy1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=149....', 'root', 'KmWHJpfTdx', Array)
[2020-05-03 13:07:09] (PDOException) **TRACE** #1 /home/fantasy1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-05-03 13:07:09] (PDOException) **TRACE** #2 /home/fantasy1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-05-03 13:07:09] (PDOException) **TRACE** #3 /home/fantasy1/public_html/modules/install/index.php(17): Flux_Connection->getStatement('SELECT VERSION(...')
[2020-05-03 13:07:09] (PDOException) **TRACE** #4 /home/fantasy1/public_html/lib/Flux/Template.php(375): include('/home/fantasy1/...')
[2020-05-03 13:07:09] (PDOException) **TRACE** #5 /home/fantasy1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-05-03 13:07:09] (PDOException) **TRACE** #6 /home/fantasy1/public_html/index.php(177): Flux_Dispatcher->dispatch(Array)
[2020-05-03 13:07:09] (PDOException) **TRACE** #7 {main}
[2020-05-03 13:07:21] (PDOException) Exception PDOException: SQLSTATE[HY000] [1130] Host 'ip169.ip-54-39-44.net' is not allowed to connect to this MySQL server
[2020-05-03 13:07:21] (PDOException) **TRACE** #0 /home/fantasy1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=149....', 'root', 'KmWHJpfTdx', Array)
[2020-05-03 13:07:21] (PDOException) **TRACE** #1 /home/fantasy1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-05-03 13:07:21] (PDOException) **TRACE** #2 /home/fantasy1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-05-03 13:07:21] (PDOException) **TRACE** #3 /home/fantasy1/public_html/modules/install/index.php(17): Flux_Connection->getStatement('SELECT VERSION(...')
[2020-05-03 13:07:21] (PDOException) **TRACE** #4 /home/fantasy1/public_html/lib/Flux/Template.php(375): include('/home/fantasy1/...')
[2020-05-03 13:07:21] (PDOException) **TRACE** #5 /home/fantasy1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-05-03 13:07:21] (PDOException) **TRACE** #6 /home/fantasy1/public_html/index.php(177): Flux_Dispatcher->dispatch(Array)
[2020-05-03 13:07:21] (PDOException) **TRACE** #7 {main}
[2020-05-03 13:16:13] (PDOException) Exception PDOException: SQLSTATE[HY000] [1130] Host 'ip169.ip-54-39-44.net' is not allowed to connect to this MySQL server
[2020-05-03 13:16:13] (PDOException) **TRACE** #0 /home/fantasy1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=149....', 'root', 'KmWHJpfTdx', Array)
[2020-05-03 13:16:13] (PDOException) **TRACE** #1 /home/fantasy1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-05-03 13:16:13] (PDOException) **TRACE** #2 /home/fantasy1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-05-03 13:16:13] (PDOException) **TRACE** #3 /home/fantasy1/public_html/modules/install/index.php(17): Flux_Connection->getStatement('SELECT VERSION(...')
[2020-05-03 13:16:13] (PDOException) **TRACE** #4 /home/fantasy1/public_html/lib/Flux/Template.php(375): include('/home/fantasy1/...')
[2020-05-03 13:16:13] (PDOException) **TRACE** #5 /home/fantasy1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-05-03 13:16:13] (PDOException) **TRACE** #6 /home/fantasy1/public_html/index.php(177): Flux_Dispatcher->dispatch(Array)
[2020-05-03 13:16:13] (PDOException) **TRACE** #7 {main}
[2020-05-03 13:16:56] (PDOException) Exception PDOException: SQLSTATE[HY000] [1130] Host 'ip169.ip-54-39-44.net' is not allowed to connect to this MySQL server
[2020-05-03 13:16:56] (PDOException) **TRACE** #0 /home/fantasy1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=149....', 'root', 'KmWHJpfTdx', Array)
[2020-05-03 13:16:56] (PDOException) **TRACE** #1 /home/fantasy1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-05-03 13:16:56] (PDOException) **TRACE** #2 /home/fantasy1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-05-03 13:16:56] (PDOException) **TRACE** #3 /home/fantasy1/public_html/modules/install/index.php(17): Flux_Connection->getStatement('SELECT VERSION(...')
[2020-05-03 13:16:56] (PDOException) **TRACE** #4 /home/fantasy1/public_html/lib/Flux/Template.php(375): include('/home/fantasy1/...')
[2020-05-03 13:16:56] (PDOException) **TRACE** #5 /home/fantasy1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-05-03 13:16:56] (PDOException) **TRACE** #6 /home/fantasy1/public_html/index.php(177): Flux_Dispatcher->dispatch(Array)
[2020-05-03 13:16:56] (PDOException) **TRACE** #7 {main}
[2020-05-03 13:17:02] (PDOException) Exception PDOException: SQLSTATE[HY000] [1130] Host 'ip169.ip-54-39-44.net' is not allowed to connect to this MySQL server
[2020-05-03 13:17:02] (PDOException) **TRACE** #0 /home/fantasy1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=149....', 'root', 'KmWHJpfTdx', Array)
[2020-05-03 13:17:02] (PDOException) **TRACE** #1 /home/fantasy1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-05-03 13:17:02] (PDOException) **TRACE** #2 /home/fantasy1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-05-03 13:17:02] (PDOException) **TRACE** #3 /home/fantasy1/public_html/modules/install/index.php(17): Flux_Connection->getStatement('SELECT VERSION(...')
[2020-05-03 13:17:02] (PDOException) **TRACE** #4 /home/fantasy1/public_html/lib/Flux/Template.php(375): include('/home/fantasy1/...')
[2020-05-03 13:17:02] (PDOException) **TRACE** #5 /home/fantasy1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-05-03 13:17:02] (PDOException) **TRACE** #6 /home/fantasy1/public_html/index.php(177): Flux_Dispatcher->dispatch(Array)
[2020-05-03 13:17:02] (PDOException) **TRACE** #7 {main}
