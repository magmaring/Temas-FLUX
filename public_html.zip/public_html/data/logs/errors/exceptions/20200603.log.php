<?php exit('Forbidden'); ?>
[2020-06-03 12:17:25] (Flux_Error) Exception Flux_Error: Critical MySQL error in Installer/Updater: Table 'cp_v4p_sites' already exists
[2020-06-03 12:17:25] (Flux_Error) **TRACE** #0 /home/fantasy1/public_html/lib/Flux/Installer/Schema.php(155): Flux_Installer_Schema->install(20151101202810)
[2020-06-03 12:17:25] (Flux_Error) **TRACE** #1 /home/fantasy1/public_html/lib/Flux/Installer/MainServer.php(46): Flux_Installer_Schema->update()
[2020-06-03 12:17:25] (Flux_Error) **TRACE** #2 /home/fantasy1/public_html/modules/install/index.php(83): Flux_Installer_MainServer->updateAll()
[2020-06-03 12:17:25] (Flux_Error) **TRACE** #3 /home/fantasy1/public_html/lib/Flux/Template.php(375): include('/home/fantasy1/...')
[2020-06-03 12:17:25] (Flux_Error) **TRACE** #4 /home/fantasy1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-06-03 12:17:25] (Flux_Error) **TRACE** #5 /home/fantasy1/public_html/index.php(177): Flux_Dispatcher->dispatch(Array)
[2020-06-03 12:17:25] (Flux_Error) **TRACE** #6 {main}
