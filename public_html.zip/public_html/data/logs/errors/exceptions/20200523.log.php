<?php exit('Forbidden'); ?>
[2020-05-23 19:29:39] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-05-23 19:29:39] (PDOException) **TRACE** #0 /home/fantasy1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=200....', 'rlcpw9f5', 'ByzWC5Y766', Array)
[2020-05-23 19:29:39] (PDOException) **TRACE** #1 /home/fantasy1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-05-23 19:29:39] (PDOException) **TRACE** #2 /home/fantasy1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-05-23 19:29:39] (PDOException) **TRACE** #3 /home/fantasy1/public_html/themes/default/main/index.php(14): Flux_Connection->getStatement('SELECT p.`name`...')
[2020-05-23 19:29:39] (PDOException) **TRACE** #4 /home/fantasy1/public_html/lib/Flux/Template.php(400): include('/home/fantasy1/...')
[2020-05-23 19:29:39] (PDOException) **TRACE** #5 /home/fantasy1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-05-23 19:29:39] (PDOException) **TRACE** #6 /home/fantasy1/public_html/index.php(177): Flux_Dispatcher->dispatch(Array)
[2020-05-23 19:29:39] (PDOException) **TRACE** #7 {main}
