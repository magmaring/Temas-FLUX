<?php exit('Forbidden'); ?>
[2020-05-28 13:54:27] sent e-mail -- Recipient: the_malon01@hotmail.com, Subject: Reset Password
