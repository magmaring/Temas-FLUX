<?php exit('Forbidden'); ?>
[2020-05-26 02:56:59] sent e-mail -- Recipient: SlowJoker001@gmail.com, Subject: Reset Password
[2020-05-26 23:18:31] sent e-mail -- Recipient: oase_9@hotmail.com, Subject: Reset Password
[2020-05-26 23:19:34] sent e-mail -- Recipient: oase_9@hotmail.com, Subject: Password Has Been Reset
