<?php exit('Forbidden'); ?>
[2020-06-01 17:54:02] sent e-mail -- Recipient: franci_psx@hotmail.com, Subject: Reset Password
