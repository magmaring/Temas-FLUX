<?php exit('Forbidden'); ?>
[2020-08-04 00:08:28] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:29:26] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000363' ORDER BY log.time ASC' at line 1
[2020-08-04 00:29:26] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:29:26] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:29:29] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000363' ORDER BY log.time ASC' at line 1
[2020-08-04 00:29:29] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:29:29] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:29:54] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000356' ORDER BY log.time ASC' at line 1
[2020-08-04 00:29:54] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:29:54] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:29:56] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000356' ORDER BY log.time ASC' at line 1
[2020-08-04 00:29:56] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:29:56] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:29:58] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000356' ORDER BY log.time ASC' at line 1
[2020-08-04 00:29:58] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:29:58] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:30:00] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000356' ORDER BY log.time ASC' at line 1
[2020-08-04 00:30:00] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:30:00] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:47:15] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:47:16] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:47:17] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:57:01] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000065' ORDER BY log.time ASC' at line 1
[2020-08-04 00:57:01] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:57:01] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:57:04] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000065' ORDER BY log.time ASC' at line 1
[2020-08-04 00:57:04] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:57:04] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:57:07] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000065' ORDER BY log.time ASC' at line 1
[2020-08-04 00:57:07] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:57:07] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:57:11] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000065' ORDER BY log.time ASC' at line 1
[2020-08-04 00:57:11] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:57:11] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:57:18] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:57:20] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000065' ORDER BY log.time ASC' at line 1
[2020-08-04 00:57:20] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:57:20] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:57:24] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000065' ORDER BY log.time ASC' at line 1
[2020-08-04 00:57:24] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:57:24] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:57:25] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000065' ORDER BY log.time ASC' at line 1
[2020-08-04 00:57:25] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:57:25] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 00:57:26] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000065' ORDER BY log.time ASC' at line 1
[2020-08-04 00:57:26] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 00:57:26] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 01:18:36] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 01:49:38] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000356' ORDER BY log.time ASC' at line 1
[2020-08-04 01:49:38] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 01:49:38] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 01:49:42] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000356' ORDER BY log.time ASC' at line 1
[2020-08-04 01:49:42] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 01:49:42] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 01:55:47] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 01:56:36] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 01:56:51] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 01:58:25] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 01:58:56] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 01:59:48] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:01:20] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:02:07] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:02:51] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:03:15] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000356' ORDER BY log.time ASC' at line 1
[2020-08-04 02:03:15] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 02:03:15] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:03:58] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:04:54] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:05:28] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:05:33] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:05:33] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:05:55] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:06:05] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:07:17] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:09:02] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:10:12] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:11:04] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:16:11] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:17:56] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000445' ORDER BY log.time ASC' at line 1
[2020-08-04 02:17:56] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 02:17:56] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:18:12] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000445' ORDER BY log.time ASC' at line 1
[2020-08-04 02:18:12] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 02:18:12] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:18:16] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000445' ORDER BY log.time ASC' at line 1
[2020-08-04 02:18:16] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 02:18:16] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:18:26] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000445' ORDER BY log.time ASC' at line 1
[2020-08-04 02:18:26] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 02:18:26] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:18:35] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000445' ORDER BY log.time ASC' at line 1
[2020-08-04 02:18:35] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 02:18:35] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:18:38] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:18:41] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 02:56:21] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000610' ORDER BY log.time ASC' at line 1
[2020-08-04 02:56:21] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 02:56:21] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 03:03:01] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 03:03:02] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 03:56:36] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 03:56:37] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 03:56:40] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000607' ORDER BY log.time ASC' at line 1
[2020-08-04 03:56:40] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 03:56:40] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 03:56:45] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000607' ORDER BY log.time ASC' at line 1
[2020-08-04 03:56:45] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 03:56:45] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 04:04:12] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 04:15:53] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 04:32:45] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 04:34:30] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 06:16:34] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 07:27:12] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.mob_db_re' doesn't exist
[2020-08-04 07:27:12] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.monsters' doesn't exist
[2020-08-04 07:27:13] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 08:04:57] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 08:04:57] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 08:04:58] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 08:28:45] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 08:28:46] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 10:01:50] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 11:18:51] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 11:59:01] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 11:59:02] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 11:59:07] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 11:59:29] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 12:00:49] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 12:04:56] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 12:05:01] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 13:01:42] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 13:01:42] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 13:01:43] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 13:11:48] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 13:11:49] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 13:11:50] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 13:38:55] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 13:40:01] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 13:40:02] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 14:08:11] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 14:08:12] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 14:08:13] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 16:07:30] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 16:07:50] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 16:07:51] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 16:32:02] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000363' ORDER BY log.time ASC' at line 1
[2020-08-04 16:32:02] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 16:32:02] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 16:32:05] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000363' ORDER BY log.time ASC' at line 1
[2020-08-04 16:32:05] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 16:32:05] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 16:32:07] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000363' ORDER BY log.time ASC' at line 1
[2020-08-04 16:32:07] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 16:32:07] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 16:32:08] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000363' ORDER BY log.time ASC' at line 1
[2020-08-04 16:32:08] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 16:32:08] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 16:32:08] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000363' ORDER BY log.time ASC' at line 1
[2020-08-04 16:32:08] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 16:32:08] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 16:32:24] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000363' ORDER BY log.time ASC' at line 1
[2020-08-04 16:32:24] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 16:32:24] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:12:09] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000065' ORDER BY log.time ASC' at line 1
[2020-08-04 17:12:09] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 17:12:09] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:25:40] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:32:10] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:52:01] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:52:12] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:52:16] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 17:52:16] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 17:52:16] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:52:22] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 17:52:22] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 17:52:22] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:52:23] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 17:52:23] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 17:52:23] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:52:25] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 17:52:25] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 17:52:25] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:52:28] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 17:52:28] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 17:52:28] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:52:33] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 17:52:33] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 17:52:33] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:52:40] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 17:52:40] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 17:52:40] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 17:52:43] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 17:52:43] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 17:52:43] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:01:17] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 18:01:17] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 18:01:17] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:01:18] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 18:01:18] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 18:01:18] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:04:26] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 18:04:26] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 18:04:26] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:23:49] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:29:04] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 18:29:04] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 18:29:04] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:30:30] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 18:30:30] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 18:30:30] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:30:36] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000502' ORDER BY log.time ASC' at line 1
[2020-08-04 18:30:36] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 18:30:36] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:30:47] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:33:25] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:33:53] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:34:23] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:34:28] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.mob_db_re' doesn't exist
[2020-08-04 18:34:28] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.monsters' doesn't exist
[2020-08-04 18:34:28] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:34:32] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:35:44] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:36:13] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.mob_db_re' doesn't exist
[2020-08-04 18:36:13] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.monsters' doesn't exist
[2020-08-04 18:36:13] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:36:16] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:36:19] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:36:25] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:36:35] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:37:14] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:37:37] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:37:51] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:38:53] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:39:17] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:39:32] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:41:51] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:53:42] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:53:43] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 18:53:44] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 19:03:33] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 19:31:32] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 20:02:47] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 20:14:35] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 20:32:11] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 20:32:39] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 20:32:47] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.mob_db_re' doesn't exist
[2020-08-04 20:32:47] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.monsters' doesn't exist
[2020-08-04 20:32:47] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 20:32:49] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 20:33:28] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 20:33:37] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 20:33:46] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 20:33:50] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 21:01:06] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 21:06:04] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 21:06:05] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 21:06:09] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 21:06:16] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 21:55:25] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 22:06:24] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000362' ORDER BY log.time ASC' at line 1
[2020-08-04 22:06:24] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 22:06:24] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 22:06:29] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000362' ORDER BY log.time ASC' at line 1
[2020-08-04 22:06:29] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 22:06:29] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 22:11:02] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 22:11:14] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000610' ORDER BY log.time ASC' at line 1
[2020-08-04 22:11:14] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 22:11:14] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 22:11:16] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000610' ORDER BY log.time ASC' at line 1
[2020-08-04 22:11:16] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 22:11:16] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 22:11:51] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 22:12:02] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 22:12:06] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000000' ORDER BY log.time ASC' at line 1
[2020-08-04 22:12:06] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 22:12:06] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 22:12:11] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS log WHERE log.account_id = '2000000' ORDER BY log.time ASC' at line 1
[2020-08-04 22:12:11] [SQLSTATE=42000] Err 1064: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS banners' at line 1
[2020-08-04 22:12:11] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 23:10:41] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 23:29:18] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-04 23:36:35] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
