<?php exit('Forbidden'); ?>
[2020-09-06 01:50:07] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-09-06 01:50:07] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
