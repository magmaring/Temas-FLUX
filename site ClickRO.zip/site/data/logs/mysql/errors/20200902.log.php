<?php exit('Forbidden'); ?>
[2020-09-02 04:49:52] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-09-02 04:49:52] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-09-02 05:13:24] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-09-02 05:13:24] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-09-02 12:12:55] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.mob_db_re' doesn't exist
[2020-09-02 12:12:55] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.monsters' doesn't exist
