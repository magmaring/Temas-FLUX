<?php exit('Forbidden'); ?>
[2020-09-01 09:49:33] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-09-01 09:49:33] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-09-01 09:49:33] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-09-01 09:49:33] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-09-01 19:01:39] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-09-01 19:01:39] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
