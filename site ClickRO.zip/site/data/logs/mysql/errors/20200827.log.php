<?php exit('Forbidden'); ?>
[2020-08-27 00:04:34] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-27 00:14:02] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-27 00:23:58] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-27 00:28:41] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-27 00:33:39] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-27 00:42:59] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.mob_db_re' doesn't exist
[2020-08-27 00:42:59] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.monsters' doesn't exist
[2020-08-27 00:42:59] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-27 00:47:36] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-27 01:10:53] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-27 03:42:40] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-27 03:47:35] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
[2020-08-27 04:50:06] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.pvpladder' doesn't exist
