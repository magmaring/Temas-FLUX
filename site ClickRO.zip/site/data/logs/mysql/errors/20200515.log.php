<?php exit('Forbidden'); ?>
[2020-05-15 06:24:52] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-05-15 06:24:52] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-05-15 06:25:19] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-05-15 06:25:19] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-05-15 06:25:22] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-05-15 06:25:22] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.mob_db_re' doesn't exist
[2020-05-15 06:26:15] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-05-15 06:26:15] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-05-15 06:26:34] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-05-15 06:26:34] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.mob_db_re' doesn't exist
[2020-05-15 07:21:22] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-05-15 07:21:22] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-05-15 07:21:32] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-05-15 07:21:32] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-05-15 07:21:44] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-05-15 07:21:44] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
