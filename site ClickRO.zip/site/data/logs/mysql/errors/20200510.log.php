<?php exit('Forbidden'); ?>
[2020-05-10 22:21:24] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-05-10 22:21:24] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
