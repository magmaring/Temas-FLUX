<?php exit('Forbidden'); ?>
[2020-08-30 20:15:10] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-08-30 20:15:10] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-08-30 20:44:08] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-08-30 20:44:08] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-08-30 21:31:05] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-08-30 21:31:05] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
