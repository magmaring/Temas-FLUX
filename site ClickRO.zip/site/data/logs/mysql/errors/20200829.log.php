<?php exit('Forbidden'); ?>
[2020-08-29 20:57:52] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-08-29 20:57:52] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
[2020-08-29 21:59:51] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.item_db_re' doesn't exist
[2020-08-29 21:59:51] [SQLSTATE=42S02] Err 1146: Table '64202975_servidor.items' doesn't exist
