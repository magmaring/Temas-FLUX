<?php exit('Forbidden'); ?>
[2020-05-26 23:20:37] (Flux_LoginError) Exception Flux_LoginError: IP address is banned
[2020-05-26 23:20:37] (Flux_LoginError) **TRACE** #0 /home/clicker1/public_html/modules/account/create.php(76): Flux_SessionData->login('FluxRO', 'Finch', 'Gozhira1234', false)
[2020-05-26 23:20:37] (Flux_LoginError) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-05-26 23:20:37] (Flux_LoginError) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-05-26 23:20:37] (Flux_LoginError) **TRACE** #3 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-05-26 23:20:37] (Flux_LoginError) **TRACE** #4 {main}
