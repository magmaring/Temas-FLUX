<?php exit('Forbidden'); ?>
[2020-07-01 12:40:41] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] php_network_getaddresses: getaddrinfo failed: Name or service not known
[2020-07-01 12:40:41] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-01 12:40:41] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-01 12:40:41] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-01 12:40:41] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-01 12:40:41] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Godlike')
[2020-07-01 12:40:41] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-01 12:40:41] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-01 12:40:41] (PDOException) **TRACE** #7 {main}
[2020-07-01 12:40:53] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] php_network_getaddresses: getaddrinfo failed: Name or service not known
[2020-07-01 12:40:53] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-01 12:40:53] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-01 12:40:53] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-01 12:40:53] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-01 12:40:53] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Godlike')
[2020-07-01 12:40:53] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-01 12:40:53] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-01 12:40:53] (PDOException) **TRACE** #7 {main}
[2020-07-01 17:32:13] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] php_network_getaddresses: getaddrinfo failed: Name or service not known
[2020-07-01 17:32:13] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-01 17:32:13] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-01 17:32:13] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-01 17:32:13] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-01 17:32:13] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-01 17:32:13] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-01 17:32:13] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-01 17:32:13] (PDOException) **TRACE** #7 {main}
[2020-07-01 17:32:24] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] php_network_getaddresses: getaddrinfo failed: Name or service not known
[2020-07-01 17:32:24] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-01 17:32:24] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-01 17:32:24] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-01 17:32:24] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-01 17:32:24] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-01 17:32:24] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-01 17:32:24] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-01 17:32:24] (PDOException) **TRACE** #7 {main}
[2020-07-01 17:38:53] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] php_network_getaddresses: getaddrinfo failed: Name or service not known
[2020-07-01 17:38:53] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-01 17:38:53] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-01 17:38:53] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-01 17:38:53] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-01 17:38:53] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Riddler')
[2020-07-01 17:38:53] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-01 17:38:53] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-01 17:38:53] (PDOException) **TRACE** #7 {main}
[2020-07-01 17:46:09] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] php_network_getaddresses: getaddrinfo failed: Name or service not known
[2020-07-01 17:46:09] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-01 17:46:09] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-01 17:46:09] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-01 17:46:09] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-01 17:46:09] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Riddler')
[2020-07-01 17:46:09] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-01 17:46:09] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-01 17:46:09] (PDOException) **TRACE** #7 {main}
[2020-07-01 17:55:30] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] php_network_getaddresses: getaddrinfo failed: Name or service not known
[2020-07-01 17:55:30] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-01 17:55:30] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-01 17:55:30] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-01 17:55:30] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-01 17:55:30] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Amigo')
[2020-07-01 17:55:30] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-01 17:55:30] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-01 17:55:30] (PDOException) **TRACE** #7 {main}
[2020-07-01 17:56:38] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] php_network_getaddresses: getaddrinfo failed: Name or service not known
[2020-07-01 17:56:38] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-01 17:56:38] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-01 17:56:38] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-01 17:56:38] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-01 17:56:38] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Amigo')
[2020-07-01 17:56:38] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-01 17:56:38] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-01 17:56:38] (PDOException) **TRACE** #7 {main}
[2020-07-01 17:58:35] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] php_network_getaddresses: getaddrinfo failed: Name or service not known
[2020-07-01 17:58:35] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-01 17:58:35] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-01 17:58:35] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-01 17:58:35] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-01 17:58:35] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-01 17:58:35] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-01 17:58:35] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-01 17:58:35] (PDOException) **TRACE** #7 {main}
