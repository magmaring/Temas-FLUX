<?php exit('Forbidden'); ?>
[2020-08-03 20:38:23] (PDOException) Exception PDOException: SQLSTATE[HY000] [1045] Access denied for user '642029750S'@'web2.ecconetwork.com' (using password: YES)
[2020-08-03 20:38:23] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-08-03 20:38:23] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-08-03 20:38:23] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-08-03 20:38:23] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-08-03 20:38:23] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-08-03 20:38:23] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-08-03 20:38:23] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-08-03 20:38:23] (PDOException) **TRACE** #7 {main}
