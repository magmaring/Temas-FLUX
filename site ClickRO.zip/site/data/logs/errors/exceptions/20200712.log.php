<?php exit('Forbidden'); ?>
[2020-07-12 03:47:57] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 03:47:57] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 03:47:57] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 03:47:57] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 03:47:57] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 03:47:57] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Riddler')
[2020-07-12 03:47:57] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 03:47:57] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 03:47:57] (PDOException) **TRACE** #7 {main}
[2020-07-12 03:51:25] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 03:51:25] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 03:51:25] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 03:51:25] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 03:51:25] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 03:51:25] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'dledezma')
[2020-07-12 03:51:25] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 03:51:25] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 03:51:25] (PDOException) **TRACE** #7 {main}
[2020-07-12 03:51:55] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 03:51:55] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 03:51:55] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 03:51:55] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 03:51:55] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 03:51:55] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'dledezma')
[2020-07-12 03:51:55] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 03:51:55] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 03:51:55] (PDOException) **TRACE** #7 {main}
[2020-07-12 03:51:59] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 03:51:59] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 03:51:59] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 03:51:59] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 03:51:59] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 03:51:59] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Riddler')
[2020-07-12 03:51:59] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 03:51:59] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 03:51:59] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:03] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:03] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:03] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:03] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:03] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:03] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:03] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:03] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:03] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:03] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:03] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:03] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:03] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:03] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:03] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:03] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:03] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:03] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:03] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:03] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:03] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:03] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:03] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:03] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:03] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:03] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:03] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:03] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:03] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:03] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:03] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:03] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:03] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:03] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:03] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:03] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:03] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:03] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:03] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:03] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:03] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:03] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:03] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:03] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:03] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:03] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:03] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:03] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:03] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:03] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:03] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:03] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:13] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:13] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:13] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:13] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:13] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:13] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:13] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:13] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:13] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:13] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:13] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:13] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:13] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:13] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:13] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:13] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:13] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:13] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:13] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:13] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:13] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:13] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:13] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:13] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:13] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:13] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:13] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:15] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:15] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:15] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:15] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:15] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:15] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:15] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:15] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:15] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:16] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:16] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:16] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:16] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:16] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:16] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:16] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:16] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:16] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:17] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:17] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:17] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:17] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:17] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:17] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:17] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:17] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:17] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:21] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:21] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:21] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:21] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:21] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:21] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:21] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:21] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:21] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:26] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:26] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:26] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:26] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:26] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:26] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:26] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:26] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:26] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:26] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:26] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:26] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:26] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:26] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:26] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:26] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:26] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:26] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:08:31] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:08:31] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:08:31] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:08:31] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:08:31] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:08:31] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:08:31] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:08:31] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:08:31] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:12:10] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:12:10] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:12:10] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:12:10] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:12:10] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 04:12:10] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Dorzac')
[2020-07-12 04:12:10] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 04:12:10] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 04:12:10] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:12:51] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:12:51] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:12:51] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:12:51] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:12:51] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 04:12:51] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Dorzac')
[2020-07-12 04:12:51] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 04:12:51] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 04:12:51] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:13:21] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:13:21] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:13:21] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:13:21] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:13:21] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 04:13:21] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Dorzac')
[2020-07-12 04:13:21] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 04:13:21] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 04:13:21] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:17:21] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:17:21] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:17:21] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:17:21] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:17:21] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 04:17:21] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'lujapty2')
[2020-07-12 04:17:21] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 04:17:21] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 04:17:21] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:18:25] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:18:25] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:18:25] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:18:25] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:18:25] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 04:18:25] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Dorzac')
[2020-07-12 04:18:25] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 04:18:25] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 04:18:25] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:21:15] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:21:15] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:21:15] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:21:15] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:21:15] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:21:15] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:21:15] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:21:15] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:21:15] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:21:56] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:21:56] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:21:56] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:21:56] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:21:56] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:21:56] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:21:56] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:21:56] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:21:56] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:22:26] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:22:26] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:22:26] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:22:26] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:22:26] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:22:26] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:22:26] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:22:26] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:22:26] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:22:59] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:22:59] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:22:59] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:22:59] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:22:59] (PDOException) **TRACE** #3 /home/clicker1/public_html/themes/clickero/main/status.php(39): Flux_Connection->getStatement('SELECT COUNT(ch...')
[2020-07-12 04:22:59] (PDOException) **TRACE** #4 /home/clicker1/public_html/themes/clickero/header.php(85): include('/home/clicker1/...')
[2020-07-12 04:22:59] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Template.php(397): include('/home/clicker1/...')
[2020-07-12 04:22:59] (PDOException) **TRACE** #6 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:22:59] (PDOException) **TRACE** #7 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:22:59] (PDOException) **TRACE** #8 {main}
[2020-07-12 04:23:02] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:23:02] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:23:02] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:23:02] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:23:02] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:23:02] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:23:02] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:23:02] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:23:02] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:23:27] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:23:27] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:23:27] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:23:27] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:23:27] (PDOException) **TRACE** #3 /home/clicker1/public_html/themes/clickero/main/status.php(39): Flux_Connection->getStatement('SELECT COUNT(ch...')
[2020-07-12 04:23:27] (PDOException) **TRACE** #4 /home/clicker1/public_html/themes/clickero/header.php(85): include('/home/clicker1/...')
[2020-07-12 04:23:27] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Template.php(397): include('/home/clicker1/...')
[2020-07-12 04:23:27] (PDOException) **TRACE** #6 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:23:27] (PDOException) **TRACE** #7 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:23:27] (PDOException) **TRACE** #8 {main}
[2020-07-12 04:24:14] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:24:14] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:24:14] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:24:14] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:24:14] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:24:14] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:24:14] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:24:14] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:24:14] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:41:15] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:41:15] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:41:15] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:41:15] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:41:15] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:41:15] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:41:15] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:41:15] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:41:15] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:41:16] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:41:16] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:41:16] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:41:16] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:41:16] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:41:16] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:41:16] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:41:16] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:41:16] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:41:20] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:41:20] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:41:20] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:41:20] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:41:20] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:41:20] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:41:20] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:41:20] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:41:20] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:41:54] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:41:54] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:41:54] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:41:54] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:41:54] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:41:54] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:41:54] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:41:54] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:41:54] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:42:24] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:42:24] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:42:24] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:42:24] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:42:24] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:42:24] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:42:24] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:42:24] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:42:24] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:42:54] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:42:54] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:42:54] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:42:54] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:42:54] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 04:42:54] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 04:42:54] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:42:54] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:42:54] (PDOException) **TRACE** #7 {main}
[2020-07-12 04:55:05] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 04:55:05] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 04:55:05] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 04:55:05] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 04:55:05] (PDOException) **TRACE** #3 /home/clicker1/public_html/themes/clickero/main/status.php(39): Flux_Connection->getStatement('SELECT COUNT(ch...')
[2020-07-12 04:55:05] (PDOException) **TRACE** #4 /home/clicker1/public_html/themes/clickero/header.php(85): include('/home/clicker1/...')
[2020-07-12 04:55:05] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Template.php(397): include('/home/clicker1/...')
[2020-07-12 04:55:05] (PDOException) **TRACE** #6 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 04:55:05] (PDOException) **TRACE** #7 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 04:55:05] (PDOException) **TRACE** #8 {main}
[2020-07-12 05:16:11] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:16:11] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:16:11] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:16:11] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:16:11] (PDOException) **TRACE** #3 /home/clicker1/public_html/themes/clickero/main/status.php(39): Flux_Connection->getStatement('SELECT COUNT(ch...')
[2020-07-12 05:16:11] (PDOException) **TRACE** #4 /home/clicker1/public_html/themes/clickero/header.php(85): include('/home/clicker1/...')
[2020-07-12 05:16:11] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Template.php(397): include('/home/clicker1/...')
[2020-07-12 05:16:11] (PDOException) **TRACE** #6 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 05:16:11] (PDOException) **TRACE** #7 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 05:16:11] (PDOException) **TRACE** #8 {main}
[2020-07-12 05:17:30] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:17:30] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:17:30] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:17:30] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:17:30] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 05:17:30] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 05:17:30] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 05:17:30] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 05:17:30] (PDOException) **TRACE** #7 {main}
[2020-07-12 05:18:14] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:18:14] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:18:14] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:18:14] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:18:14] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 05:18:14] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 05:18:14] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 05:18:14] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 05:18:14] (PDOException) **TRACE** #7 {main}
[2020-07-12 05:18:39] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:18:39] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:18:39] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:18:39] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:18:39] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 05:18:39] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 05:18:39] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 05:18:39] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 05:18:39] (PDOException) **TRACE** #7 {main}
[2020-07-12 05:23:12] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:23:12] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:23:12] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:23:12] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:23:12] (PDOException) **TRACE** #3 /home/clicker1/public_html/themes/clickero/main/status.php(39): Flux_Connection->getStatement('SELECT COUNT(ch...')
[2020-07-12 05:23:12] (PDOException) **TRACE** #4 /home/clicker1/public_html/themes/clickero/header.php(85): include('/home/clicker1/...')
[2020-07-12 05:23:12] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Template.php(397): include('/home/clicker1/...')
[2020-07-12 05:23:12] (PDOException) **TRACE** #6 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 05:23:12] (PDOException) **TRACE** #7 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 05:23:12] (PDOException) **TRACE** #8 {main}
[2020-07-12 05:26:16] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:26:16] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:26:16] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:26:16] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:26:16] (PDOException) **TRACE** #3 /home/clicker1/public_html/themes/clickero/main/status.php(39): Flux_Connection->getStatement('SELECT COUNT(ch...')
[2020-07-12 05:26:16] (PDOException) **TRACE** #4 /home/clicker1/public_html/themes/clickero/header.php(85): include('/home/clicker1/...')
[2020-07-12 05:26:16] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Template.php(397): include('/home/clicker1/...')
[2020-07-12 05:26:16] (PDOException) **TRACE** #6 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 05:26:16] (PDOException) **TRACE** #7 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 05:26:16] (PDOException) **TRACE** #8 {main}
[2020-07-12 05:31:07] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:31:07] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:31:07] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:31:07] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:31:07] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 05:31:07] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 05:31:07] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 05:31:07] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 05:31:07] (PDOException) **TRACE** #7 {main}
[2020-07-12 05:31:10] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:31:10] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:31:10] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:31:10] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:31:10] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 05:31:10] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 05:31:10] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 05:31:10] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 05:31:10] (PDOException) **TRACE** #7 {main}
[2020-07-12 05:31:12] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:31:12] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:31:12] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:31:12] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:31:12] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 05:31:12] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 05:31:12] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 05:31:12] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 05:31:12] (PDOException) **TRACE** #7 {main}
[2020-07-12 05:34:13] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:34:13] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:34:13] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:34:13] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:34:13] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 05:34:13] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 05:34:13] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 05:34:13] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 05:34:13] (PDOException) **TRACE** #7 {main}
[2020-07-12 05:51:24] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:51:24] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:51:24] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:51:24] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:51:24] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 05:51:24] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Dulce')
[2020-07-12 05:51:24] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 05:51:24] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 05:51:24] (PDOException) **TRACE** #7 {main}
[2020-07-12 05:52:03] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:52:03] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:52:03] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:52:03] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:52:03] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 05:52:03] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Dulce')
[2020-07-12 05:52:03] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 05:52:03] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 05:52:03] (PDOException) **TRACE** #7 {main}
[2020-07-12 05:52:43] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 05:52:43] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 05:52:43] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 05:52:43] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 05:52:43] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 05:52:43] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'stromtocxic')
[2020-07-12 05:52:43] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 05:52:43] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 05:52:43] (PDOException) **TRACE** #7 {main}
[2020-07-12 06:02:28] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 06:02:28] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 06:02:28] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 06:02:28] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 06:02:28] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 06:02:28] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 06:02:28] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 06:02:28] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 06:02:28] (PDOException) **TRACE** #7 {main}
[2020-07-12 06:13:38] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 06:13:38] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 06:13:38] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 06:13:38] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 06:13:38] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 06:13:38] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Riddler')
[2020-07-12 06:13:38] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 06:13:38] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 06:13:38] (PDOException) **TRACE** #7 {main}
[2020-07-12 06:20:44] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 06:20:45] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 06:20:45] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 06:20:45] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 06:20:45] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 06:20:45] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Riddler')
[2020-07-12 06:20:45] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 06:20:45] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 06:20:45] (PDOException) **TRACE** #7 {main}
[2020-07-12 06:21:15] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 06:21:15] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 06:21:15] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 06:21:15] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 06:21:15] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 06:21:15] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Riddler')
[2020-07-12 06:21:15] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 06:21:15] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 06:21:15] (PDOException) **TRACE** #7 {main}
[2020-07-12 06:22:18] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 06:22:18] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 06:22:18] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 06:22:18] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 06:22:18] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 06:22:18] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Amigo')
[2020-07-12 06:22:18] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 06:22:18] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 06:22:18] (PDOException) **TRACE** #7 {main}
[2020-07-12 06:22:50] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 06:22:50] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 06:22:50] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 06:22:50] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 06:22:50] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 06:22:50] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Amigo')
[2020-07-12 06:22:50] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 06:22:50] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 06:22:50] (PDOException) **TRACE** #7 {main}
[2020-07-12 06:23:20] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 06:23:20] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 06:23:20] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 06:23:20] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 06:23:20] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 06:23:20] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'Amigo')
[2020-07-12 06:23:20] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 06:23:20] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 06:23:20] (PDOException) **TRACE** #7 {main}
[2020-07-12 06:42:22] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 06:42:22] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 06:42:22] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 06:42:22] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 06:42:22] (PDOException) **TRACE** #3 /home/clicker1/public_html/lib/Flux/SessionData.php(351): Flux_Connection->getStatement('SELECT login.*,...')
[2020-07-12 06:42:22] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/SessionData.php(115): Flux_SessionData->getAccount(Object(Flux_LoginAthenaGroup), 'stromtocxic')
[2020-07-12 06:42:22] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/SessionData.php(64): Flux_SessionData->initialize()
[2020-07-12 06:42:22] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(148): Flux_SessionData->__construct(Array, false)
[2020-07-12 06:42:22] (PDOException) **TRACE** #7 {main}
[2020-07-12 06:45:27] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 06:45:27] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 06:45:27] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 06:45:27] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 06:45:27] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 06:45:27] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 06:45:27] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 06:45:27] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 06:45:27] (PDOException) **TRACE** #7 {main}
[2020-07-12 06:46:19] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 06:46:19] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 06:46:19] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 06:46:19] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 06:46:19] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 06:46:19] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 06:46:19] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 06:46:19] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 06:46:19] (PDOException) **TRACE** #7 {main}
[2020-07-12 06:47:02] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-07-12 06:47:02] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-07-12 06:47:02] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-07-12 06:47:02] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-07-12 06:47:02] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-07-12 06:47:02] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-07-12 06:47:02] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-07-12 06:47:02] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-07-12 06:47:02] (PDOException) **TRACE** #7 {main}
