<?php exit('Forbidden'); ?>
[2020-05-31 22:28:08] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-05-31 22:28:08] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-05-31 22:28:08] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-05-31 22:28:08] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-05-31 22:28:08] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-05-31 22:28:08] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-05-31 22:28:08] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-05-31 22:28:08] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-05-31 22:28:08] (PDOException) **TRACE** #7 {main}
[2020-05-31 22:28:10] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-05-31 22:28:10] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-05-31 22:28:10] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-05-31 22:28:10] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-05-31 22:28:10] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-05-31 22:28:10] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-05-31 22:28:10] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-05-31 22:28:10] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-05-31 22:28:10] (PDOException) **TRACE** #7 {main}
[2020-05-31 22:28:47] (PDOException) Exception PDOException: SQLSTATE[HY000] [2002] Connection timed out
[2020-05-31 22:28:47] (PDOException) **TRACE** #0 /home/clicker1/public_html/lib/Flux/Connection.php(81): PDO->__construct('mysql:host=sql1...', '642029750S', 'jhh9Aj7Tcg5B5Wp...', Array)
[2020-05-31 22:28:47] (PDOException) **TRACE** #1 /home/clicker1/public_html/lib/Flux/Connection.php(94): Flux_Connection->connect(Object(Flux_Config))
[2020-05-31 22:28:47] (PDOException) **TRACE** #2 /home/clicker1/public_html/lib/Flux/Connection.php(159): Flux_Connection->getConnection()
[2020-05-31 22:28:47] (PDOException) **TRACE** #3 /home/clicker1/public_html/modules/main/index.php(10): Flux_Connection->getStatement('SELECT title, b...')
[2020-05-31 22:28:47] (PDOException) **TRACE** #4 /home/clicker1/public_html/lib/Flux/Template.php(375): include('/home/clicker1/...')
[2020-05-31 22:28:47] (PDOException) **TRACE** #5 /home/clicker1/public_html/lib/Flux/Dispatcher.php(170): Flux_Template->render()
[2020-05-31 22:28:47] (PDOException) **TRACE** #6 /home/clicker1/public_html/index.php(176): Flux_Dispatcher->dispatch(Array)
[2020-05-31 22:28:47] (PDOException) **TRACE** #7 {main}
