<?php
return array(
	0 => 'Healing',
	//1 => 'Unknown',
	2 => 'Usable',
	3 => 'Etc',
	4 => 'Armor',
	5 => 'Weapon',
	6 => 'Card',
	7 => 'Pet Egg',
	8 => 'Pet Armor',
	//9 => 'Unknown2',
	10 => 'Ammo',
	11 => 'Delay Consume',
	12 => 'Shadow Equipment',
	18 => 'Cash Shop Reward'
)
?>
