<?php
return array(
	5 => array( // Weapons
		0 => 'Bare Fist',
		1 => 'Dagger',
		2 => 'One-Handed Sword',
		3 => 'Two-Handed Sword',
		4 => 'One-Handed Spear',
		5 => 'Two-Handed Spear',
		6 => 'One-Handed Axe',
		7 => 'Two-Handed Axe',
		8 => 'Mace',
		//9 => 'Unused',
		10 => 'Staff',
		11 => 'Bow',
		12 => 'Knuckle',
		13 => 'Musical Instrument',
		14 => 'Whip',
		15 => 'Book',
		16 => 'Katar',
		17 => 'Revolver',
		18 => 'Rifle',
		19 => 'Gatling Gun',
		20 => 'Shotgun',
		21 => 'Grenade Launcher',
		22 => 'Fuuma Shuriken',
		23 => 'Two-handed staves',
		//24 => '',
		25 => 'Dual-wield Daggers',
		26 => 'Dual-wield Swords',
		27 => 'Dual-wield Axes',
		28 => 'Dagger + Sword',
		29 => 'Dagger + Axe',
		30 => 'Sword + Axe'
	),
	10 => array( // Ammo
		1 => 'Arrow',
		2 => 'Throwing Dagger',
		3 => 'Bullet',
		4 => 'Shell',
		5 => 'Grenade',
		6 => 'Shuriken',
		7 => 'Kunai',
		8 => 'Cannonballs',
		9 => 'Throwable Item (Sling Item)'
	)
)
?>
