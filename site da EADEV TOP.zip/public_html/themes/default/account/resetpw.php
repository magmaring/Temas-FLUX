<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>Reset Password</h2>
