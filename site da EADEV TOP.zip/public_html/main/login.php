<?php if (!defined('FLUX_ROOT')) exit; ?>
<?php
if (!defined('FLUX_ROOT')) exit;

if (Flux::config('UseLoginCaptcha') && Flux::config('EnableReCaptcha')) {
	$recaptcha = Flux::config('ReCaptchaPublicKey');
	$theme = Flux::config('ReCaptchaTheme');
}

$title = Flux::message('LoginTitle');
$loginLogTable = Flux::config('FluxTables.LoginLogTable');

if (count($_POST)) {
	$serverGroupName = $params->get('server');
	$username = $params->get('username');
	$password = $params->get('password');
	$code     = $params->get('security_code');
	
	try {
		$session->login($serverGroupName, $username, $password, $code);
		$returnURL = $params->get('return_url');
		
		if ($session->loginAthenaGroup->loginServer->config->getUseMD5()) {
			$password = Flux::hashPassword($password);
		}
		
		$sql  = "INSERT INTO {$session->loginAthenaGroup->loginDatabase}.$loginLogTable ";
		$sql .= "(account_id, username, password, ip, error_code, login_date) ";
		$sql .= "VALUES (?, ?, ?, ?, ?, NOW())";
		$sth  = $session->loginAthenaGroup->connection->getStatement($sql);
		$sth->execute(array($session->account->account_id, $username, $password, $_SERVER['REMOTE_ADDR'], null));
		
		if ($returnURL) {
			$this->redirect($returnURL);
		}
		else {
			$this->redirect();
		}
	}
	catch (Flux_LoginError $e) {
		if ($username && $password && $e->getCode() != Flux_LoginError::INVALID_SERVER) {
			$loginAthenaGroup = Flux::getServerGroupByName($serverGroupName);

			$sql = "SELECT account_id FROM {$loginAthenaGroup->loginDatabase}.login WHERE ";
			
			if (!$loginAthenaGroup->loginServer->config->getNoCase()) {
				$sql .= "CAST(userid AS BINARY) ";
			} else {
				$sql .= "userid ";
			}
			
			$sql .= "= ? LIMIT 1";
			$sth = $loginAthenaGroup->connection->getStatement($sql);
			$sth->execute(array($username));
			$row = $sth->fetch();

			if ($row) {
				$accountID = $row->account_id;
				
				if ($loginAthenaGroup->loginServer->config->getUseMD5()) {
					$password = Flux::hashPassword($password);
				}

				$sql  = "INSERT INTO {$loginAthenaGroup->loginDatabase}.$loginLogTable ";
				$sql .= "(account_id, username, password, ip, error_code, login_date) ";
				$sql .= "VALUES (?, ?, ?, ?, ?, NOW())";
				$sth  = $loginAthenaGroup->connection->getStatement($sql);
				$sth->execute(array($accountID, $username, $password, $_SERVER['REMOTE_ADDR'], $e->getCode()));
			}
		}
		
		switch ($e->getCode()) {
			case Flux_LoginError::UNEXPECTED:
				$errorMessage = Flux::message('UnexpectedLoginError');
				break;
			case Flux_LoginError::INVALID_SERVER:
				$errorMessage = Flux::message('InvalidLoginServer');
				break;
			case Flux_LoginError::INVALID_LOGIN:
				$errorMessage = Flux::message('InvalidLoginCredentials');
				break;
			case Flux_LoginError::BANNED:
				$errorMessage = Flux::message('TemporarilyBanned');
				break;
			case Flux_LoginError::PERMABANNED:
				$errorMessage = Flux::message('PermanentlyBanned');
				break;
			case Flux_LoginError::IPBANNED:
				$errorMessage = Flux::message('IpBanned');
				break;
			case Flux_LoginError::INVALID_SECURITY_CODE:
				$errorMessage = Flux::message('InvalidSecurityCode');
				break;
			case Flux_LoginError::PENDING_CONFIRMATION:
				$errorMessage = Flux::message('PendingConfirmation');
				break;
			default:
				$errorMessage = Flux::message('CriticalLoginError');
				break;
		}
	}
}

$serverNames = $this->getServerNames();
?>
</div>
<section class="ro-login-container">
<div class="container">
    <div class="row align-items-center">
        <div class="col-sm">
            <div class="kafra" data-aos="fade-left" data-aos-delay="500" data-aos-duration="600" data-aos-easing="ease-in-sine"></div>
        </div>
        <div class="col-sm">

            <?php if (isset($errorMessage)): ?>
            <p class="red"><?php echo htmlspecialchars($errorMessage) ?></p>
            <?php else: ?>

            <?php endif ?>
            <div class="card" data-aos="fade-down" data-aos-duration="1000" data-aos-delay="100" data-aos-easing="ease-in-sine">
            <div class="card-body">
                <div class="d-flex mb-4">
                    <div class="flex-item">
                        <img src="<?php echo $this->themePath('css/key.svg') ?>" class="ro-login-key align-middle">
                    </div>
                    <div class="flex-grow align-self-center ro-panel-title">
                        <p class="panel-title">LOGIN</p>
                        <p class="panel-subtitle">access your account</p>
                    </div>
                </div>


            <?php if ($session->isLoggedIn()): ?>
                <p>
                    You are currently logged in as 
                    <strong>
                        <a href="<?php echo $this->url('account', 'view') ?>" title="View account">
                            <?php echo htmlspecialchars($session->account->userid) ?>
                        </a>
                    </strong>
                    on <?php echo htmlspecialchars($session->serverName) ?>.
                        
                    <?php if (count($athenaServerNames=$session->getAthenaServerNames()) > 1): ?>
                    Your preferred server is:
                    <select name="preferred_server" onchange="updatePreferredServer(this)"<?php if (count($athenaServerNames=$session->getAthenaServerNames()) === 1) echo ' disabled="disabled"'  ?>>
                        <?php foreach ($athenaServerNames as $serverName): ?>
                        <option value="<?php echo htmlspecialchars($serverName) ?>"<?php if ($server->serverName == $serverName) echo ' selected="selected"' ?>><?php echo htmlspecialchars($serverName) ?></option>
                        <?php endforeach ?>
                    </select>.
                    <?php endif ?>
                    <form action="<?php echo $this->urlWithQs ?>" method="post" name="preferred_server_form" style="display: none">
                        <input type="hidden" name="preferred_server" value="" />
                    </form>
                </p>

                <div class="ro-login-menu-container d-flex justify-content-center">
                    <div class="ro-login-menu text-center">
                        <a href="<?php echo $this->url('account', 'view') ?>" title="View account">
                            <img src="<?php echo $this->themePath('img/view-account.gif') ?>" class="mx-auto">
                            View Account
                        </a>
                    </div>
                    <div class="ro-login-menu text-center">
                         <a href="<?php echo $this->url('account', 'changepass') ?>" title="Change Pass">
                            <img src="<?php echo $this->themePath('img/change-pass.gif') ?>" class="mx-auto">
                            Change Pass
                        </a>
                    </div>
                    <div class="ro-login-menu text-center">
                         <a href="<?php echo $this->url('account', 'changemail') ?>" title="Change Email">
                            <img src="<?php echo $this->themePath('img/change-email.gif') ?>" class="mx-auto">
                            Change Email
                        </a>
                    </div>
                    <div class="ro-login-menu text-center">
                         <a href="<?php echo $this->url('voteforpoints') ?>" title="Vote for Points">
                            <img src="<?php echo $this->themePath('img/vote-for-points.gif') ?>" class="mx-auto">
                            Vote Points
                        </a>
                    </div>
                    <div class="ro-login-menu text-center ro-logout">
                         <a href="<?php echo $this->url('account','logout') ?>" title="Logout">
                            <img src="<?php echo $this->themePath('img/logout.gif') ?>" class="mx-auto">
                            Logout Account
                        </a>
                    </div>
                </div>
            <?php else: ?>
            <form action="<?php echo $this->url('account', 'login', array('return_url' => $params->get('return_url'))) ?>" method="post">
                <?php if (count($serverNames) === 1): ?>
                <input type="hidden" name="server" value="<?php echo htmlspecialchars($session->loginAthenaGroup->serverName) ?>">
                <?php endif ?>
                <div class="form-group">
                    <label for="login-username">Username</label>
                    <input type="text" name="username" class="form-control" id="login_username" placeholder="Username">
                </div>
                <div class="form-group">
                    <label for="login-password">Password</label>
                    <input type="password" name="password" class="form-control" id="login_password" placeholder="Password">
                </div>
                    <?php if (count($serverNames) > 1): ?>
                    <div class="form-group">
                        <label for="login_server"><?php echo htmlspecialchars(Flux::message('AccountServerLabel')) ?></label>
                            <select name="server" id="login_server"<?php if (count($serverNames) === 1) echo ' disabled="disabled"' ?>>
                                <?php foreach ($serverNames as $serverName): ?>
                                <option value="<?php echo htmlspecialchars($serverName) ?>"><?php echo htmlspecialchars($serverName) ?></option>
                                <?php endforeach ?>
                            </select>

                    </div>
                    <?php endif ?>
                    <?php if (Flux::config('UseLoginCaptcha')): ?>
                        <div class="form-group">
                        <?php if (Flux::config('EnableReCaptcha')): ?>
                        <label for="register_security_code"><?php echo htmlspecialchars(Flux::message('AccountSecurityLabel')) ?></label>
                        <div class="g-recaptcha" data-theme = "<?php echo $theme;?>" data-sitekey="<?php echo $recaptcha ?>"></div>
                        <?php else: ?>
                        <label for="register_security_code"><?php echo htmlspecialchars(Flux::message('AccountSecurityLabel')) ?></label>

                            <div class="security-code">
                                <img src="<?php echo $this->url('captcha') ?>" />
                            </div>
                            <input type="text" name="security_code" id="register_security_code" />
                            <div style="font-size: smaller;" class="action">
                                <strong><a href="javascript:refreshSecurityCode('.security-code img')"><?php echo htmlspecialchars(Flux::message('RefreshSecurityCode')) ?></a></strong>
                            </div>
                        </div>
                        <?php endif ?>
                    <?php endif ?>
                    
                    <?php if ($auth->actionAllowed('account', 'create')): ?>
                    <p><?php printf(Flux::message('LoginPageMakeAccount'), $this->url('account', 'create')); ?></p>
                    <?php endif ?>
                    <input type="submit" class="form-control btn btn-primary" value="<?php echo htmlspecialchars(Flux::message('LoginButton')) ?>" />
            </form>
            <?php endif ?>
            </div>
            </div>
    </div>
</div>
</section>
<div>