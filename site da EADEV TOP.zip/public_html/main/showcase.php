<?php if (!defined('FLUX_ROOT')) exit; ?>
</div>
<div id="showcase">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-sm">
                <div class="woe-sura" data-aos="fade-left" data-aos-duration="1000" data-aos-easing="ease-in-sine"></div>
            </div>
            <div class="col-sm-7 text-left">
                <h2 class="article-title" data-aos="fade-down">INTENSE WOE ACTION</h2>
                <h2 class="subtitle" data-aos="fade-down" data-aos-delay="300">Still undecided? Watch this in-game footage.</h2>
                <div class="embed-responsive embed-responsive-16by9" data-aos="fade-right" data-aos-delay="600">
                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/n1W6e64WHqk" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
<div>
