<?php if (!defined('FLUX_ROOT')) exit; ?>
<div id="about">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-sm-7 text-right">
                <h2 class="article-title">
                    ABOUT THE SERVER
                    <span class="bar-right">|</span>
                </h2>
                <div class="row features">
                    <div class="col-sm-4">
                        <article class="feature" data-aos="fade-down">
                            <img src="<?php echo $this->themePath('img/feature_gepard.png') ?>" class="mx-auto">
                            Gepard Shield 3.0 Protected
                        </article>
                    </div>
                    <div class="col-sm-4">
                        <article class="feature" data-aos="fade-down" data-aos-delay="300">
                        <img src="<?php echo $this->themePath('img/feature_fast.png') ?>" class="mx-auto">
                            100% No Lag Guaranteed
                        </article>
                    </div>
                    <div class="col-sm-4">
                        <article class="feature" data-aos="fade-down" data-aos-delay="600">
                        <img src="<?php echo $this->themePath('img/feature_friendly.png') ?>" class="mx-auto">
                            Friendly Community
                        </article>
                    </div>
                </div>
                    <p data-aos="fade-left" data-aos-delay="50">✔ Freebies and Solo Packs</p>
                    <p data-aos="fade-left" data-aos-delay="100">✔ 255/100 Frost Server</p>
                    <p data-aos="fade-left" data-aos-delay="150">✔ Transcendent Class</p>
                    <p data-aos="fade-left" data-aos-delay="200">✔ Balanced Gameplay</p>
                    <p data-aos="fade-left" data-aos-delay="250">✔ 196 Max Aspd.</p>
                    <p data-aos="fade-left" data-aos-delay="300">✔ Easy Quest Items.</p>
                    <p data-aos="fade-left" data-aos-delay="350">✔ Max SP CAP: 6000</p>
                    <p data-aos="fade-left" data-aos-delay="400">✔ No Overpowered Items, etc.</p>
                    <p data-aos="fade-left" data-aos-delay="450">✔ Anti DDOS Protected</p>
                    <p data-aos="fade-left" data-aos-delay="500">✔ Location: Los Angeles, Californa.</p>
                    <p data-aos="fade-left" data-aos-delay="550">✔ Modified Soul Link System</p>
            </div>
            <div class="col-sm">
                <div class="char-about" data-aos="fade-right" data-aos-duration="1000" data-aos-easing="ease-in-sine"></div>
            </div>
        </div>
    </div>
</div>
<div>
