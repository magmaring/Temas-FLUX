<?php if (!defined('FLUX_ROOT')) exit; ?>

<div class="navbar navbar-expand-sm text-center mx-auto">
  <div class="nav navbar-nav mx-auto">
    <a class="nav-item nav-link text-center" href="?">
      <img src="<?php echo $this->themePath('img/home.gif') ?>">
      HOME
    </a>
    <a class="nav-item nav-link" href="#">
      <img src="<?php echo $this->themePath('img/information.gif') ?>" />
      INFO
    </a>
    <a class="nav-item nav-link" href="#">
      <img src="<?php echo $this->themePath('img/forums.gif') ?>" />
      FORUMS
    </a>
    <a class="nav-item nav-link" href="#">
      <img src="<?php echo $this->themePath('img/download.gif') ?>" />
      DOWNLOAD
    </a>
    <div class="navbar-brand ro-logo-container mx-auto d-none d-md-block d-lg-block d-xl-block">
      <img class="ro-logo" src="<?php echo $this->themePath('img/logo.png') ?>" data-aos="zoom-in" data-aos-duration="1000">
    </div>
    <a class="nav-item nav-link" href="#">
      <img src="<?php echo $this->themePath('img/donation.gif') ?>" />
      DONATE
    </a>
    <a class="nav-item nav-link" href="#">
      <img src="<?php echo $this->themePath('img/item.gif') ?>" />
      ItemDB
    </a>
    <a class="nav-item nav-link" href="#">
      <img src="<?php echo $this->themePath('img/mob.gif') ?>" />
      MobDB
    </a>
    <a class="nav-item nav-link" href="#">
      <?php include $this->themePath('main/status.php', true) ?>
      Status
    </a>
  </div>
</div>

