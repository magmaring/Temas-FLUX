<?php if (!defined('FLUX_ROOT')) exit; ?>
<?php include $this->themePath('main/login.php', true) ?>
<?php include $this->themePath('main/about.php', true) ?>
<?php include $this->themePath('main/showcase.php', true) ?>