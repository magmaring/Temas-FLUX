<?php
if (!defined('FLUX_ROOT')) exit;

$title = "Server Information";
?>