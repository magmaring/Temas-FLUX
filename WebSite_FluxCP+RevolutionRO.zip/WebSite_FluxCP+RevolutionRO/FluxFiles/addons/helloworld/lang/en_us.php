<?php
return array(
	'HelloWorld'       => 'Hello, World!',
	'HelloInfoText'    => 'This is a “Hello World” sample from an add-on!',
	'HelloVersionText' => 'Your Flux Control Panel version is %s'
);
?>