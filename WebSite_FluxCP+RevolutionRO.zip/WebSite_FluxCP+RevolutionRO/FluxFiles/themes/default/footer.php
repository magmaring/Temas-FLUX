<?php if (!defined('FLUX_ROOT')) exit; ?>
		<?php if($_thisModule=='main' AND $_thisAction=='index'): ?>
				<?php else: ?>
			</div>
		</section>
		<?php endif; ?>
		<footer class="footer">
			<div class="container">
				<div class="row">
					<div class="col-xs-2">
						<div class="footer-nav">
							<h4>Userful links</h4>
							<ul>
								<li><a href="<?php echo $this->url('main'); ?>">Home</a></li>
								<li><a href="<?php echo $this->url('account','create'); ?>">Registro</a></li>
								<li><a href="<?php echo $this->url('main','downloads'); ?>">Download</a></li>
								<li><a href="<?php echo $this->url('main','info'); ?>">Information</a></li>
								<li><a href="<?php echo $this->url('ranking','character'); ?>">Rankings</a></li>
								<li><a href="<?php echo $EADev['forum']; ?>" target="_blank">Forum</a></li>
							</ul>
						</div>
					</div>
					<div class="col-xs-2">
						<h4>Social Links</h4>
						<ul>
							<li><a target="_blank" href="<?php echo $EADev['facebook']; ?>">Facebook</a></li>
							<li><a target="_blank" href="<?php echo $EADev['twitter']; ?>">Twitter</a></li>
							<li><a target="_blank" href="<?php echo $EADev['youtube']; ?>">Youtube</a></li>
							<li><a target="_blank" href="<?php echo $EADev['instagram']; ?>">Instagram</a></li>
						</ul>
					</div>
					<div class="col-xs-4 footer-news">
						<h4>LATEST NEWS</h4>
						<ul class="no-list">
							<?php 
								if($EADev['enablerss']) {
									require_once $this->themePath('main/rsslib.php', true);
								}
								$news = RSS_Display(array('news' => $EADev['news'], 'update' => $EADev['updates'], 'event' => $EADev['events']), 4); 
								foreach ($news as $item): ?>
							<li>
								<a href="<?php echo $item['link']; ?>" target="_blank">
									<?php echo substr($item['title'], 0, 40); ?>..
									<span class="datetime"><?php echo date('d M Y', strtotime($item['date'])); ?></span>
								</a>
							</li>
							<?php endforeach; ?>
						</ul>
					</div>
					<div class="col-xs-3">
						<iframe src="https://www.facebook.com/plugins/page.php?href=<?php echo $EADev['facebook']; ?>%2F&tabs&width=270&height=214&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=1617016161843836" width="270" height="214" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
					</div>
				</div>
			</div>
		</footer>
		<div class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-xs-3">
						<a href="//www.ea-dev.com" target="_blank"><img src="<?php echo $this->themePath('img/eadev.png'); ?>" alt="EADev"></a>
					</div>
					<div class="col-xs-6">
						<div class="copyright-text">
							Copyright <?php echo date('Y'); ?>!<br/> All Registered Trademarks belong 
							to their Respective Owners and Gravity Co.LTD. <br/>
							<strong>Website Designed and Coded by <a href="//www.ea-dev.com" target="_blank">EADev</a>.</strong>
						</div>
					</div>
					<div class="col-xs-3 text-center">
						<a href="">
							<img src="<?php echo $this->themePath('img/logo-footer.png'); ?>" alt="" class="img-responsive">
						</a>
					</div>
				</div>
			</div>
		</div>

		<div class="modal main-modal" tabindex="-1" role="dialog">
			<div class="modal-dialog bounceIn animated modal-md" role="document">
				<div class="modal-content">
					<div class="modal-body">
						<div class="modal-header">
							<button type="button" class="close pull-right" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4 class="text-center">Log In to access your account</h4>
						</div>
						<div class="row">
							<div class="col-md-12">
								<form action="<?php echo $this->url('account','login'); ?>" method="post" accept-charset="utf-8">
									<?php if (count($serverNames) === 1): ?>
									<input type="hidden" name="server" value="<?php echo htmlspecialchars($session->loginAthenaGroup->serverName) ?>">
									<?php endif ?>
									<div class="form-group">
										<input type="text" name="username" class="form-control" placeholder="Username">
									</div>
									<div class="form-group">
										<input type="password" name="password" class="form-control" placeholder="Password">
									</div>
									<div class="form-group text-right">
										<a href="<?php echo $this->url('account','resetpass'); ?>">Forgot password?</a>
									</div>
									<button type="submit" class="btn btn-theme btn-block" name="submit" value="submit">Submit</button>
								</form>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						Do not have account? <a href="<?php echo $this->url('account','create'); ?>">Create an Account</a>
					</div>
				</div>
			</div>
		</div>
		<script src="https://use.fontawesome.com/d5e6268bc7.js"></script>
	</body>
</html>
