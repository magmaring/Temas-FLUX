<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2> <?php echo htmlspecialchars(Flux::message('ResendHeading')) ?> </h2>
<?php if (!empty($errorMessage)): ?>
<p class="red"><?php echo htmlspecialchars($errorMessage) ?></p>
<?php endif ?>
<p><?php echo htmlspecialchars(Flux::message('ResendInfo')) ?></p>
<form action="<?php echo $this->urlWithQs ?>" method="post" class="generic-form form-horizontal">
	<table class="generic-form-table">
		<?php if (count($serverNames) > 1): ?>
		<tr>
			<th><label for="login"><?php echo htmlspecialchars(Flux::message('ResendServerLabel')) ?></label></th>
			<td>
				<select name="login" id="login"<?php if (count($serverNames) === 1) echo ' disabled="disabled"' ?>>
				<?php foreach ($serverNames as $serverName): ?>
					<option value="<?php echo htmlspecialchars($serverName) ?>"<?php if ($params->get('server') == $serverName) echo ' selected="selected"' ?>><?php echo htmlspecialchars($serverName) ?></option>
				<?php endforeach ?>
				</select>
			</td>
			<td><p><?php echo htmlspecialchars(Flux::message('ResendServerInfo')) ?></p></td>
		</tr>
		<?php endif ?>
		<tr>
			<td>
				<div class="form-group">
					<label for="register_password" class="control-label col-md-4"><?php echo htmlspecialchars(Flux::message('ResendAccountLabel')) ?></label>
					<div class="col-md-8">
						<input class="form-control" type="text" name="userid" id="userid" />
						<p><?php echo htmlspecialchars(Flux::message('ResendAccountInfo')) ?></p>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="form-group">
					<label for="register_password" class="control-label col-md-4"><?php echo htmlspecialchars(Flux::message('ResendEmailLabel')) ?></label>
					<div class="col-md-8">
						<input class="form-control" type="text" name="email" id="email" />
						<p><?php echo htmlspecialchars(Flux::message('ResendEmailInfo')) ?></p>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<div class="form-group">
					<div class="col-md-4"></div>
					<div class="col-md-8">
						<button class="btn btn-btn btn-block" type="submit" value=""><?php echo htmlspecialchars(Flux::message('ResendButton')) ?></button>
					</div>
				</div>
			</td>
		</tr>
	</table>
</form>