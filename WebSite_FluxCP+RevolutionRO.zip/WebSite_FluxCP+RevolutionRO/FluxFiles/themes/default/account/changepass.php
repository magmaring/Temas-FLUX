<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2><?php echo htmlspecialchars(Flux::message('PasswordChangeHeading')) ?></h2>
<?php if (!empty($errorMessage)): ?>
	<p class="red"><?php echo htmlspecialchars($errorMessage) ?></p>
<?php else: ?>
	<p><?php echo htmlspecialchars(Flux::message('PasswordChangeInfo')) ?></p>
<?php endif ?>
<br />
<form action="<?php echo $this->urlWithQs ?>" method="post" class="generic-form form-horizontal">
	<table class="generic-form-table">
		<tr>
			<td>
				<div class="form-group">
					<label for="currentpass" class="control-label col-md-4"><?php echo htmlspecialchars(Flux::message('CurrentPasswordLabel')) ?></label>
					<div class="col-md-8">
						<input class="form-control" type="password" name="currentpass" id="currentpass" value="" />
						<p><?php echo htmlspecialchars(Flux::message('PasswordChangeNote')) ?></p>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="form-group">
					<label for="newpass" class="control-label col-md-4"><?php echo htmlspecialchars(Flux::message('NewPasswordLabel')) ?></label>
					<div class="col-md-8">
						<input class="form-control" type="password" name="newpass" id="newpass" value="" />
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="form-group">
					<label for="newpass" class="control-label col-md-4"><?php echo htmlspecialchars(Flux::message('NewPasswordConfirmLabel')) ?></label>
					<div class="col-md-8">
						<input class="form-control" type="password" name="confirmnewpass" id="confirmnewpass" value="" />
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<div class="form-group">
					<div class="col-md-4"></div>
					<div class="col-md-8">
						<button class="btn btn-btn btn-block" type="submit" value=" "><?php echo htmlspecialchars(Flux::message('PasswordChangeButton')) ?></button>
					</div>
				</div>
			</td>
		</tr>
	</table>
</form>