<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>Downloads</h2>
<p class="note">FOR CONTROL PANEL ADMINISTRATOR: You may add your server's contents in this view file directly. The location of the view file is: <?php echo __FILE__ ?></p>