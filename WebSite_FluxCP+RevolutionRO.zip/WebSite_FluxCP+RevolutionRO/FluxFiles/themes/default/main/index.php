<?php if (!defined('FLUX_ROOT')) exit;

$news = $mvps = $pvpers = array();
if( $EADev['enablerss'] ) {
	include $this->themePath('main/rsslib.php', true);
	$news = RSS_Display( array(
		'news' => $EADev['news'], 
		'events' => $EADev['events'], 
		'updates' => $EADev['updates'] 
	), 4 );
}

$sqlpvp = "SELECT `pvpladder`.`kills`, `pvpladder`.`streaks`, `pvpladder`.`deaths`, `char`.`name`, `char`.`class`, `char`.`base_level`, `char`.`job_level`, `char`.`account_id`, `char`.`online`, `login`.`sex` FROM `pvpladder` LEFT JOIN `char` ON `char`.`char_id` = `pvpladder`.`char_id` LEFT JOIN `login` ON `login`.`account_id` = `char`.`account_id` WHERE `login`.`state` = '0' ORDER BY `pvpladder`.`kills` DESC, `pvpladder`.`streaks` DESC, `pvpladder`.`deaths` DESC, `char`.`base_exp` DESC LIMIT 0, 3"; 
$sthpvp = $server->connection->getStatement($sqlpvp);
$sthpvp->execute();
$pvpers = $sthpvp->fetchAll();

$sqlmvp = "SELECT mvp.*, l.sex, c.class, c.base_level, c.job_level FROM mvp LEFT JOIN `char` c ON mvp.char_id = c.char_id LEFT JOIN login l ON c.account_id = l.account_id ORDER BY mvp.kills DESC LIMIT 0,3"; 
$sthmvp = $server->connection->getStatement($sqlmvp);
$sthmvp->execute();
$mvps = $sthmvp->fetchAll();

$castleNames = Flux::config('CastleNames')->toArray();
$sqlgvg	= "SELECT guild_castle.guild_id AS gcgid, guild_castle.castle_id AS cid, guild.name, guild.master, guild.guild_id AS ggid, guild.emblem_len FROM guild_castle LEFT JOIN guild ON guild_castle.guild_id = guild.guild_id WHERE guild_castle.castle_id IN (" . implode(",", array_keys($EADev['castles'])) . ") ORDER BY guild_castle.castle_id";
$sth = $server->connection->getStatement($sqlgvg);
$sth->execute();
$castlesOccupieds = $sth->fetchAll();

?>
<header class="header">
	<div class="effect-1 appear" data-animation="bounceInRight"></div>
	<div class="effect-2 appear" data-animation="bounceInLeft"></div>
	<div class="effect-3 appear" data-animation="bounceInRight"></div>
	<div class="slides hidden-xs">
		<div class="slide slide-1">&nbsp;</div>
		<div class="slide slide-2">&nbsp;</div>
		<div class="slide slide-3">&nbsp;</div>
	</div>
</header>
<div class="welcome">
	<div class="container">
		<div class="row">
			<div class="col-xs-2">
				<div class="button-h appear">
					<div class="button-h-img">
						<img src="<?php echo $this->themePath('img/button-1.png'); ?>" alt="">
					</div>
					<div class="button-h-text">
						<a href="<?php echo $this->url('account','create'); ?>">Registro<span>clique aqui para criar sua conta</span></a>
					</div>
				</div>
			</div>
			<div class="col-xs-2">
				<div class="button-h appear">
					<div class="button-h-img">
						<img src="<?php echo $this->themePath('img/button-2.png'); ?>" alt="">
					</div>
					<div class="button-h-text">
						<a href="<?php echo $this->url('main','download'); ?>">Download<span>último<br/>patch</span></a>
					</div>
				</div>
			</div>
			<div class="col-xs-2">
				<div class="button-h appear">
					<div class="button-h-img">
						<img src="<?php echo $this->themePath('img/button-3.png'); ?>" alt="">
					</div>
					<div class="button-h-text">
						<a href="<?php echo $this->url('vote'); ?>">Vote 4 Points<span>vote no servidor e receba pontos</span></a>
					</div>
				</div>
			</div>
			<div class="col-xs-6">
				<h1 class="appear" data-animation="fade">Bem Vindo aos servidores de Revolution Ragnarok Online</h1>
				<p class="appear" data-animation="fade">
					Staff Ativa trabalhando para a melhoria do servidor, toda sugestão é bem-vinda, conheça nosso fórum e deixe sua opinião.</p>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
			</div>
		</div>
	</div>
</div>
<div class="news-events">
	<div class="container">
		<h2>Notícias da Semana..</h2>
		<div class="news-items">
			<?php foreach ($news as $key => $_news): ?>
			<div class="news-item appear" data-animation="bounceIn">
				<div class="news-image">
					<img src="<?php echo $this->themePath('img/news-' . ($key+1) . '.png'); ?>" alt="" class="img-responsive">
					<div class="news-label <?php echo $_news['image']; ?>"><?php echo ucfirst($_news['image']); ?></div>
				</div>
				<div class="news-description">
					<a href="<?php echo $_news['link']; ?>" target="_blank"><?php echo $_news['title']; ?></a>
					<div class="news-info">
						Revolution <span><?php echo date('d M, Y', strtotime($_news['date'])); ?></span>
					</div>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</div>
<div class="rankings">
	<div class="tabs">
		<ul class="nav nav-tabs" role="tablist">
			<li role="presentation" class="active">
				<a href="#MvP" aria-controls="MvP" role="tab" data-toggle="tab">
					Rankings MvP<span>top 3 mvp killers</span>
					<img src="<?php echo $this->themePath('img/mvp-icon.png'); ?>" alt="">
				</a>
			</li>
			<li role="presentation">
				<a href="#PvP" aria-controls="PvP" role="tab" data-toggle="tab">
					Rankings PvP<span>top 3 players</span>
					<img src="<?php echo $this->themePath('img/pvp-icon.png'); ?>" alt="">
				</a>
			</li>
		</ul>
	</div>
	<div class="tab-content">
		<div role="tabpanel" class="tab-pane active" id="MvP">
			<div class="container-rank">
				<h3>Top 3 MvP Killers</h3>
				<div class="row">
					<?php foreach ($mvps as $key => $mvp): ?>
					<div class="col-xs-4">
						<div class="rank appear" data-animation="fadeInDown">
							<div class="rank-head">
								<div class="rank-image">
									<img src="<?php echo $this->themePath('img/jobs/' . $mvp->sex . '/' . $mvp->class . '.gif'); ?>" alt="">
								</div>
								<div class="rank-leader">
									<div class="rank-title">#<?php echo $key+1; ?></div>
									<div class="rank-name"><?php echo $mvp->name; ?></div>
									<div class="rank-job"><?php echo $this->jobClassText( $mvp->class ); ?></div>
								</div>
							</div>
							<div class="ranks">
								<ul class="nav nav-justified">
									<li>
										<?php echo number_format( $mvp->kills ); ?> <small>MvP kills</small>
									</li>
									<li>
										<?php echo number_format( $mvp->base_level ); ?>/<?php echo number_format( $mvp->job_level ); ?> <small>Level</small>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<div role="tabpanel" class="tab-pane" id="PvP">
			<div class="container-rank">
				<h3>Top 3 PvP Killers</h3>
				<div class="row">
					<?php foreach ($pvpers as $key => $pvp): ?>
					<div class="col-xs-4">
						<<div class="rank appear" data-animation="fadeInDown">
							<div class="rank-head">
								<div class="rank-image">
									<img src="<?php echo $this->themePath('img/jobs/' . $pvp->sex . '/' . $pvp->class . '.gif'); ?>" alt="">
								</div>
								<div class="rank-leader">
									<div class="rank-title">#<?php echo $key+1; ?></div>
									<div class="rank-name"><?php echo $pvp->name; ?></div>
									<div class="rank-job"><?php echo $this->jobClassText( $pvp->class ); ?></div>
								</div>
							</div>
							<div class="ranks">
								<ul class="nav nav-justified">
									<li>
										<?php echo number_format( $pvp->kills ); ?> <small>Player kills</small>
									</li>
									<li>
										<?php echo number_format( $pvp->deaths ); ?> <small>Deaths</small>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>

	<div class="features">
		<div class="feature appear" data-animation="bounce">
			<div class="feature-icon">
				<img src="<?php echo $this->themePath('img/feature-1.png'); ?>" alt="">
			</div>
			<div class="feature-text">
				<h3>Friendly Staff</h3>
				<small>our staff is always ready to help</small>
				<div class="icon"><i class="fa fa-headphones"></i></div>
			</div>
		</div>
		<div class="feature appear" data-animation="bounce">
			<div class="feature-icon">
				<img src="<?php echo $this->themePath('img/feature-2.png'); ?>" alt="">
			</div>
			<div class="feature-text">
				<h3>100% bug free</h3>
				<small>you will not find<br/>any bugs</small>
				<div class="icon"><i class="fa fa-bug"></i></div>
			</div>
		</div>
		<div class="feature appear" data-animation="bounce">
			<div class="feature-icon">
				<img src="<?php echo $this->themePath('img/feature-3.png'); ?>" alt="">
			</div>
			<div class="feature-text">
				<h3>Regular Events</h3>
				<small>regular automated events</small>
				<div class="icon"><i class="fa fa-snapchat-ghost"></i></div>
			</div>
		</div>
		<div class="feature appear" data-animation="bounce">
			<div class="feature-icon">
				<img src="<?php echo $this->themePath('img/feature-4.png'); ?>" alt="">
			</div>
			<div class="feature-text">
				<h3>Shield Protection</h3>
				<small>server protected with gepard shield</small>
				<div class="icon"><i class="fa fa-shield"></i></div>
			</div>
		</div>
		<div class="feature appear" data-animation="bounce">
			<div class="feature-icon">
				<img src="<?php echo $this->themePath('img/feature-5.png'); ?>" alt="">
			</div>
			<div class="feature-text">
				<h3>Donation</h3>
				<small>get your donations<br/>ingame</small>
				<div class="icon"><i class="fa fa-gift"></i></div>
			</div>
		</div>
	</div>
</div>

<div class="castle-holders">
	<div class="castles">
		<?php foreach ($castlesOccupieds as $castleo): ?>
		<div class="castle appear">
			<div class="button-h">
				<div class="button-h-img">
					<img src="<?php echo $this->themePath('img/castle-flag.png'); ?>" alt="">
					<?php if( $castleo->emblem_len ): ?>
						<img class="emblem" src="<?php echo $this->emblem($castleo->gcgid); ?>" title="<?php echo "Guild: " . $castleo->name . "<br/>Castle: ". $castleNames[$castleo->cid]; ?>">
					<?php else: ?>
						<img class="emblem" src="<?php echo $this->themePath('img/emblem.png'); ?>" alt="">
					<?php endif; ?>
				</div>
				<div class="button-h-text">
					<a><?php echo $castleNames[$castleo->cid]; ?><span><?php echo $EADev['castles'][$castleo->cid]; ?></span></a>
				</div>
			</div>
		</div>
		<?php endforeach; ?>
	</div>
</div>

<section class="rules">
	<div class="container">
		<h2>Regras</h2>
		<div class="row">
			<div class="col-xs-4">
				<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
				<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
			</div>
			<div class="col-xs-4">
				<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
				<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
			</div>
		</div>
	</div>
</section>