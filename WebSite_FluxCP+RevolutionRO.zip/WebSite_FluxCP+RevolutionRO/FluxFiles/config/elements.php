<?php
// rA elements.
return array(
	0 => 'Neutral',
	1 => 'Water',
	2 => 'Earth',
	3 => 'Fire',
	4 => 'Wind',
	5 => 'Poison',
	6 => 'Holy',
	7 => 'Dark',
	8 => 'Ghost',
	9 => 'Undead'
);
?>