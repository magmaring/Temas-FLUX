<?php if (!defined('FLUX_ROOT')) exit; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<?php if (isset($metaRefresh)): ?>
		<meta http-equiv="refresh" content="<?php echo $metaRefresh['seconds'] ?>; URL=<?php echo $metaRefresh['location'] ?>" />
		<?php endif ?>
		<title><?php echo Flux::config('SiteTitle'); if (isset($title)) echo ": $title" ?></title>
		<link rel="stylesheet" href="<?php echo $this->themePath('css/flux.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $this->themePath('css/style.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<link href="<?php echo $this->themePath('css/flux/unitip.css') ?>" rel="stylesheet" type="text/css" media="screen" title="" charset="utf-8" />
		<?php if (Flux::config('EnableReCaptcha')): ?>
		<link href="<?php echo $this->themePath('css/flux/recaptcha.css') ?>" rel="stylesheet" type="text/css" media="screen" title="" charset="utf-8" />
		<?php endif ?>
		<script type="text/javascript" src="<?php echo $this->themePath('js/jquery-1.7.2.min.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/jquery.cycle2.min.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/jquery.cycle2.carousel.min.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/flux.datefields.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/flux.unitip.js') ?>"></script>
		<script type="text/javascript">
			$(document).ready(function(){});
			$(document).ready(function(){
				$('#halltab > div').hide();$('#halltab > div:first').show();$('#halltab > ul li:first').addClass('active');$('#halltab > ul li a').click(function(){$('#halltab > ul li').removeClass('active');$(this).parent().addClass('active'); var currentTab = $(this).attr('href'); $('#halltab > div').hide(); $(currentTab).show();return false;});
				$('.money-input').keyup(function() {
					var creditValue = parseInt($(this).val() / <?php echo Flux::config('CreditExchangeRate') ?>, 10);
					if (isNaN(creditValue))
						$('.credit-input').val('?');
					else
						$('.credit-input').val(creditValue);
				}).keyup();
				$('.credit-input').keyup(function() {
					var moneyValue = parseFloat($(this).val() * <?php echo Flux::config('CreditExchangeRate') ?>);
					if (isNaN(moneyValue))
						$('.money-input').val('?');
					else
						$('.money-input').val(moneyValue.toFixed(2));
				}).keyup();
				processDateFields();
			});
			function reload(){
				window.location.href = '<?php echo $this->url ?>';
			}
		</script>
		<script type="text/javascript">
			function updatePreferredServer(sel){
				var preferred = sel.options[sel.selectedIndex].value;
				document.preferred_server_form.preferred_server.value = preferred;
				document.preferred_server_form.submit();
			}
			var spinner = new Image();
			spinner.src = '<?php echo $this->themePath('img/spinner.gif') ?>';
			function refreshSecurityCode(imgSelector){
				$(imgSelector).attr('src', spinner.src);
				var clean = <?php echo Flux::config('UseCleanUrls') ? 'true' : 'false' ?>;
				var image = new Image();
				image.src = "<?php echo $this->url('captcha') ?>"+(clean ? '?nocache=' : '&nocache=')+Math.random();
				$(imgSelector).attr('src', image.src);
			}
			function toggleSearchForm()
			{
				$('.search-form').slideToggle('fast');
			}
		</script>
		<?php if (Flux::config('EnableReCaptcha') && Flux::config('ReCaptchaTheme')): ?>
		<script type="text/javascript">
			 var RecaptchaOptions = {
			    theme : '<?php echo Flux::config('ReCaptchaTheme') ?>'
			 };
		</script>
		<?php endif ?>
	</head>
	<body>
	<?php $MainConf = include ('main/MainConfig.php'); ?>
		<div id="wrapper">
			<div id="main">
				<div id="header">
					<div class="logo">
						<a href="<?php echo $this->url('main'); ?>"><img src="<?php echo $this->themePath('img/logo.png'); ?>" alt="" /></a>
					</div>
					<div class="nav">
						<div class="register">
							<a href="<?php echo $this->url('account','create'); ?>"><img src="<?php echo $this->themePath('img/register.png'); ?>" alt="" /></a>
						</div>
						<div class="info">
							<a href="http://keyron-ro.com/forum/index.php?/topic/2-bienvenido-a-keyron-ragnarok-online"><img src="<?php echo $this->themePath('img/info.png'); ?>" alt="" /></a>
						</div>
						<div class="donate">
							<a href="<?php echo $this->url('donate'); ?>"><img src="<?php echo $this->themePath('img/donate.png'); ?>" alt="" /></a>
						</div>
						<div class="forum">
							<a href="<?php echo $MainConf['forum']; ?>" target="_blank	"><img src="<?php echo $this->themePath('img/forum.png'); ?>" alt="" /></a>
						</div>
						<div class="download">
							<a href="<?php echo $this->url('pages','content&path=download'); ?>"><img src="<?php echo $this->themePath('img/download.png'); ?>" alt="" /></a>
						</div>
					</div>
					<div class="clear"></div>
				</div>
				<div id="container">
					<div class="containerLeft">
						<div class="accountPanel">
							<?php include ('main/loginpanel.php'); ?>
						</div>
						<div class="fiveLinks">
							<ul>
								<li><a href="<?php echo $this->url('main'); ?>"><img src="<?php echo $this->themePath('img/fiveLinks.png'); ?>" alt="" /></a></li>
								<li><a href="<?php echo $this->url('voteforpoints'); ?>"><img src="<?php echo $this->themePath('img/fiveLinks.png'); ?>" alt="" /></a></li>
								<li><a href="<?php echo $this->url('pages','content&path=staff'); ?>"><img src="<?php echo $this->themePath('img/fiveLinks.png'); ?>" alt="" /></a></li>
								<li><a href="<?php echo $this->url('pages','content&path=rules'); ?>"><img src="<?php echo $this->themePath('img/fiveLinks.png'); ?>" alt="" /></a></li>
								<li><a href="<?php echo $this->url('pages','content&path=custom_system'); ?>"><img src="<?php echo $this->themePath('img/fiveLinks.png'); ?>" alt="" /></a></li>
							</ul>
						</div>
						<div class="rankings">
							<ul>
								<li><a href="<?php echo $this->url('ranking','woe'); ?>"><img src="<?php echo $this->themePath('img/twoLinks.png'); ?>" alt="" /></a></li>

							</ul>
						</div>
					</div>
					<div class="containerMiddle">
						<div class="containerMiddleTop">
							<div class="serverStatus">
								<?php include ('main/status.php'); ?>
							</div>
						</div>
						<div class="containerMiddleCenter">
							<?php if ($message=$session->getMessage()): ?>
								<p class="message"><?php echo htmlspecialchars($message) ?></p>
							<?php endif ?>
							<?php include 'main/submenu.php' ?>
							<?php include 'main/pagemenu.php' ?>
							<?php if (in_array($params->get('module'), array('donate', 'purchase'))) include 'main/balance.php' ?>
