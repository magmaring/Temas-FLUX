<div id="fb-root"></div>

<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '1780902278855869',
      xfbml      : true,
      version    : 'v2.7'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>
<?php if (!defined('FLUX_ROOT')) exit; ?>
						</div><!-- containerMiddleCenter end -->
						<div class="containerMiddleBottom"></div>
					</div><!-- containerMiddle end -->
					<div class="containerRight">
						<div class="woe">
							<?php include ('main/woe.php'); ?>
						</div>
						<div class="halloffame">
							<?php include ('main/halloffame.php'); ?>
						</div>
						<div class="facebook">
							<div class="fb-page" data-href="https://www.facebook.com/KeyronRO/" data-width="165" data-height="165" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/KeyronRO/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/KeyronRO/">Keyron RO</a></blockquote></div>
						</div>
					</div>
					<div class="clear"></div>
				</div><!-- container end -->
			</div><!-- main end -->
			<div id="footer">
				<div class="pony">
					<a href="http://pony-vpshosting.com/"><img src="<?php echo $this->themePath('img/ponyvps.png'); ?>" alt="" /></a>
				</div>
				<div class="copyright">
					<p class="first">&copy; 2016 Keyron - Ragnarok Online</p>
					<p class="second">All other trademarks are property of Gravity &amp; Lee Myoungjin (Studio DTDS) and their respective owners.</p>
				</div>
				<div class="yoshu">
					<a href="https://www.facebook.com/yoshudesign"><img src="<?php echo $this->themePath('img/yoshu.png'); ?>" alt="" /></a>
				</div>
				<div class="clear"></div>
			</div>
		</div><!-- wrapper end -->
	</body>
</html>
