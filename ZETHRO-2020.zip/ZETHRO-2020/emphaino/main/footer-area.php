<?php if (!defined('FLUX_ROOT')) exit; ?>
<div style="padding: 1rem;">
This is customizable footer-area. To change its content edit <tt><?php echo __FILE__ ?></tt>.
</div>