Emphaino Theme for FluxCP
=========================

This is Emphaino Theme for Wordpress ported to FluxCP.

It works in IE9, Chrome, Safari, Firefox, Opera. IE8 is somehow usable.

To use this theme for your FluxCP installation:
 - set 'ThemeName' to 'emphaino' in `config/application.php`
 - set 'OutputCleanHTML' to false in `config/application.php`

[Emphaino for Wordpress on GitHub]: https://github.com/sriniguna/emphaino
