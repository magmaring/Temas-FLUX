<?php if (!defined('FLUX_ROOT')) exit; ?>
<div class="loginPanel">
	<?php if (!$session->isLoggedIn()): ?>      
	<form action="<?php echo $this->url('account', 'login', array('return_url' => $params->get('return_url'))) ?>" method="post" autocomplete="off">
		<input type="hidden" name="server" value="<?php echo htmlspecialchars($session->loginAthenaGroup->serverName) ?>">
		<table cellpadding="0" cellspacing="0">
			<tr>
				<td>
					<span class="addon"><img src="<?php echo $this->themePath('img/user.png'); ?>" alt=""></span>
					<input type="text" name="username" class="textClass" placeholder="Username" />
				</td>
			</tr>
			<tr>
				<td>
					<span class="addon"><img src="<?php echo $this->themePath('img/key.png'); ?>" alt=""></span>
					<input type="password" name="password" class="textClass" placeholder="Password" />
				</td>
			</tr>
			<tr>
				<td class="loginBtns">
					<input type="submit" value=" " class="loginBtn" />
					<a href="<?php echo $this->url('account','resetpass');?>">
						<img src="<?php echo $this->themePath('img/forgot-password.png'); ?>" alt="">
					</a>
				</td>
			</tr>
		</table>
	</form>
	<?php else:?>
		<div class="logged">
			<p>
				You are currently logged in as <strong><a href="<?php echo $this->url('account', 'view') ?>" title="View account"><?php echo htmlspecialchars($session->account->userid) ?></a></strong>
				on <?php echo htmlspecialchars($session->serverName) ?>.
			</p>
			<a href="<?php echo $this->url('account','view')?>">My Account</a>
			<a href="<?php echo $this->url('account','logout')?>" onclick="return confirm('Are you sure you want to logout?')">Logout</a>
		</div>
	<?php endif?>
</div>