<?php
return array(

	// Rate my server link
	'rms' 			=> 	'http://ratemyserver.net',
		
	// Forums link here
	'forum' 		=> 	'http://forum.com',

	// video link
	'video' 		=> '<iframe width="232" height="185" src="//www.youtube.com/embed/ZT1wb8_tcYU" frameborder="0" allowfullscreen></iframe>',

	// Facebook
	'Facebook'			=>	'http://facebook.com/EADevOfficial',
	'Twitter'			=>	'http://twitter.com',
	'Youtube'			=>	'http://youtube.com',
		
	// RSS Links
	'EnableRSS'		=> true,
	'news'			=>	'http://localhost/rss.xml',

	'Slider' => array(
		'slide.png',
		'slide.png',
		'slide.png',
	),

	'itemshop'		=>	array(
		'5001',
		'5001',
		'5001',
		'5001',
	),

	// Castles to be shown on Guild section
	'Castles'		=>	array(
		5		=>	'11:00 PM - 1:00 AM',
		15		=>	'12:00 PM - 2:00 AM',
		17		=>	'01:00 PM - 3:00 AM',
		12		=>	'02:00 PM - 4:00 AM'
	),
)
?>