<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>Support</h2>
<p class="note">The Page content goes inside <?php echo __FILE__; ?></p>