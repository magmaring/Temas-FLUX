<?php if (!defined('FLUX_ROOT')) exit; 

$cache = FLUX_DATA_DIR.'/tmp/ServerStatus.cache';
if (file_exists($cache) && (time() - filemtime($cache)) < (Flux::config('ServerStatusCache') * 600)) {
    $serverStatus = unserialize(file_get_contents($cache));
}
else {
    $serverStatus = array();
    foreach (Flux::$loginAthenaGroupRegistry as $groupName => $loginAthenaGroup) {
        if (!array_key_exists($groupName, $serverStatus)) {
            $serverStatus[$groupName] = array();
        }

        $loginServerUp = $loginAthenaGroup->loginServer->isUp();

        foreach ($loginAthenaGroup->athenaServers as $athenaServer) {
            $serverName = $athenaServer->serverName;

            $sql = "SELECT COUNT(char_id) AS players_online FROM {$athenaServer->charMapDatabase}.char WHERE online > 0";
            $sth = $loginAthenaGroup->connection->getStatement($sql);
            $sth->execute();
            $res = $sth->fetch();

            $sqlwoestatus = "SELECT value FROM mapreg WHERE varname = '$\woeStatus' LIMIT 0 , 1";
            $sthwoestatus = $loginAthenaGroup->connection->getStatement($sqlwoestatus);
            $sthwoestatus->execute();
            $woestatusresult = $sthwoestatus->fetch();

            $serverStatus[$groupName][$serverName] = array(
                'loginServerUp' => $loginServerUp,
                'charServerUp' => $athenaServer->charServer->isUp(),
                'mapServerUp' => $athenaServer->mapServer->isUp(),
                'woeStatus' => intval($woestatusresult ? $woestatusresult->value : 0),
                'playersOnline' => intval($res ? $res->players_online : 0)
            );
        }
    }
    
    $fp = fopen($cache, 'w');
    if (is_resource($fp)) {
        fwrite($fp, serialize($serverStatus));
        fclose($fp);
    }
}
$online = "<img src=". $this->themePath('img/online.png') . " />";
$offline = "<img src=". $this->themePath('img/offline.png') . " />";
    foreach ($serverStatus as $privServerName => $gameServers): 
        foreach ($gameServers as $serverName => $gameServer): 
            if ($gameServer['loginServerUp']) { $loginonline = true; } else { $loginonline = false; } 
            if ($gameServer['charServerUp']) { $charonline = true; } else { $charonline = false; }
            if ($gameServer['mapServerUp']) { $maponline = true; } else { $maponline = false; } 
            $onlinecount = $gameServer['playersOnline'];
            $woe_status = $gameServer['woeStatus'];
        endforeach;
    endforeach;
?>
<div class="server-status">
    <div class="online-count">
        <?php echo $onlinecount; ?>
    </div>
    <span class="status"><?php if ( $maponline ) { echo '<span class="online">on</span>'; } else { echo '<span class="offline">off</span>'; } ?></span>
    <span class="woe"><?php if ( $woe_status ) { echo '<span class="online">on</span>'; } else { echo '<span class="offline">off</span>'; } ?></span>
</div>