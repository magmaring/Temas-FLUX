<?php if (!defined('FLUX_ROOT')) exit; ?>
<div class="index">
	<div class="slider">
		<div class="cycle-slideshow" data-cycle-fx="scrollHorz" >
			<?php foreach ($EADev['Slider'] as $slide): ?>
				<img src="<?php echo $this->themePath('img/' . $slide); ?>" alt="">
			<?php endforeach; ?>
		</div>
	</div>
	<div class="welcome">
		<h2>Welcome to yourro name</h2>
		<p>
			Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, a
		</p>
	</div>
	<div class="news">
		<div class="news-feeds">
			<?php if( $EADev['EnableRSS'] ): 
				include('rsslib.php');
				echo RSS_Display( array($EADev['news']), 8 );
				endif;
			?>
		</div>
	</div>
	<div class="itemshop">
		<div class="cycle-slideshow" data-cycle-fx="carousel">
			<?php foreach ($EADev['itemshop'] as $item): ?>
				<img src="<?php echo $this->themePath('img/item/' . $item . '.gif'); ?>" alt="">
			<?php endforeach; ?>
		</div>
	</div>
</div>