<?php if (!defined('FLUX_ROOT')) exit;
	$castleNames = Flux::config('CastleNames')->toArray();
	$sqlcastles	= "SELECT guild_castle.guild_id AS gcgid, guild_castle.castle_id AS cid, guild.name, guild.master, guild.guild_id AS ggid, guild.emblem_len FROM guild_castle LEFT JOIN guild ON guild_castle.guild_id = guild.guild_id WHERE guild_castle.castle_id IN (" . implode(",", array_keys($EADev['Castles'])) . ")";
	$sth  = $server->connection->getStatement($sqlcastles);
	$sth->execute();
	$castles = $sth->fetchAll();

	$sqlguild  = "SELECT g.guild_id, g.name AS gname, g.emblem_len, (SELECT COUNT( c.castle_id ) FROM guild_castle c WHERE c.guild_id = g.guild_id ) AS castles, g.master, (SELECT COUNT( char_id ) FROM  `char` WHERE  `char`.guild_id = g.guild_id ) AS members FROM guild AS g LEFT JOIN  `char` AS ch ON ch.char_id = g.char_id LEFT JOIN login ON login.account_id = ch.account_id ORDER BY castles DESC, members DESC , g.max_member DESC , g.next_exp ASC LIMIT 1";
	$sthgvg  = $server->connection->getstatement($sqlguild);
	$sthgvg->execute();
	$topGuild = $sthgvg->fetch();

	$sqlplayers  = "SELECT * FROM pvpladder ORDER BY kills DESC LIMIT 0, 5";
	$sthgvg  = $server->connection->getstatement($sqlplayers);
	$sthgvg->execute();
	$topPlayers = $sthgvg->fetchAll();

?>
<div class="guild">
	<div class="woes">
		<ul>
			<?php foreach( $EADev['Castles'] as $cid => $time ): ?>
			<li>
				<div class="castle-name"><?php echo $castleNames[$cid]; ?></div>
				<div class="castle-time"><?php echo $time; ?></div>
				<?php $found = 0; foreach ($castles as $c): ?>
					<?php if( $c->emblem_len AND $c->cid == $cid ): $found = 1; ?>
						<img src="<?php echo $this->emblem($c->ggid) ?>" title="<?php echo "Guild: " . $c->name . "<br/>Master: ". $c->master; ?>" />
					<?php endif; ?>
				<?php endforeach; ?>
				<?php if( ! $found ): ?>
					<img src="<?php echo $this->themePath('img/noemblem.jpg'); ?>" title="Guild: -<br/>Castle: -"/>
				<?php endif; ?>
			</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<div class="top-guild">
		<?php if( $topGuild ): ?>
			<div class="castle-time"><?php echo $topGuild->gname; ?></div>
			<?php if( $topGuild->emblem_len ): ?>
				<img src="<?php echo $this->emblem($topGuild->guild_id) ?>" title="<?php echo "Guild: " . $topGuild->gname . "<br/>Master: ". $topGuild->master . "<br/>Castles: " . $topGuild->castles; ?>" />
			<?php else: ?>
				<img src="<?php echo $this->themePath('img/noemblem.jpg'); ?>" title="Guild: No Guild<br/>Castle: -"/>
			<?php endif; ?>
		<?php endif; ?>
	</div>
</div>
<div class="player-rankings">
	<?php if( $topPlayers ): ?>
		<?php $topPlayer = $topPlayers[0]; ?>
		<div class="top-player">
			<div class="player-name"><?php echo $topPlayer->name; ?></div>
			<div class="kills"><?php echo number_format($topPlayer->kills); ?></div>
			<div class="deaths"><?php echo number_format($topPlayer->deaths); ?></div>
		</div>
		<div class="players">
			<ul>
				<?php $i=0; foreach ($topPlayers as $player): $i++; if( $i == 1 ) continue; ?>
					<li><?php echo $player->name; ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>
</div>