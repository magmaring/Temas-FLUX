<?php if (!defined('FLUX_ROOT')) exit; ?>
						</div>
						<div class="container-bottom"></div>
					</div>
					<div class="container-right">
						<?php include $this->themePath('main/rankings.php', true); ?>
						<div class="video">
							<?php echo $EADev['video']; ?>
						</div>
					</div>
				</div>
				<div class="footer">
					<div class="footer-inner">
						<div class="designer">
							<a href="http://ea-dev.com" target="_blank"><img src="<?php echo $this->themePath('img/renn.png'); ?>" alt=""></a>
						</div>
						<div class="copyright">
							Copyright <?php echo date('Y'); ?>.<br/>
							All Registered Trademarks belong to their Respective Owners and Gravity Co.LTD.<br/>
							Website Design/Coded by <a href="//ea-dev.com" target="_blank">EADev</a>
						</div>
						<div class="coder">
							<a href="http://www.ea-dev.com" target="_blank"><img src="<?php echo $this->themePath('img/eadev.png'); ?>" alt=""></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
