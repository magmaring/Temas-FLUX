<?php if (!defined('FLUX_ROOT')) exit; ?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<?php if (isset($metaRefresh)): ?>
		<meta http-equiv="refresh" content="<?php echo $metaRefresh['seconds'] ?>; URL=<?php echo $metaRefresh['location'] ?>" />
		<?php endif ?>
		<title><?php echo Flux::config('SiteTitle'); if (isset($title)) echo ": $title" ?></title>
		<link rel="stylesheet" href="<?php echo $this->themePath('css/flux.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $this->themePath('css/style.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<link href="<?php echo $this->themePath('css/flux/unitip.css') ?>" rel="stylesheet" type="text/css" media="screen" title="" charset="utf-8" />
		<?php if (Flux::config('EnableReCaptcha')): ?>
		<link href="<?php echo $this->themePath('css/flux/recaptcha.css') ?>" rel="stylesheet" type="text/css" media="screen" title="" charset="utf-8" />
		<?php endif ?>
		<script type="text/javascript" src="<?php echo $this->themePath('js/jquery-1.8.3.min.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/flux.datefields.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/flux.unitip.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/jquery.cycle2.min.js') ?>"></script>
		<script type="text/javascript" src="<?php echo $this->themePath('js/jquery.cycle2.carousel.min.js') ?>"></script>
		<script type="text/javascript">
			$(document).ready(function(){
				$('.money-input').keyup(function() {
					var creditValue = parseInt($(this).val() / <?php echo Flux::config('CreditExchangeRate') ?>, 10);
					if (isNaN(creditValue))
						$('.credit-input').val('?');
					else
						$('.credit-input').val(creditValue);
				}).keyup();
				$('.credit-input').keyup(function() {
					var moneyValue = parseFloat($(this).val() * <?php echo Flux::config('CreditExchangeRate') ?>);
					if (isNaN(moneyValue))
						$('.money-input').val('?');
					else
						$('.money-input').val(moneyValue.toFixed(2));
				}).keyup();
				processDateFields();
			});
			function reload(){
				window.location.href = '<?php echo $this->url ?>';
			}
		</script>
		<script type="text/javascript">
			function updatePreferredServer(sel){
				var preferred = sel.options[sel.selectedIndex].value;
				document.preferred_server_form.preferred_server.value = preferred;
				document.preferred_server_form.submit();
			}
			function updatePreferredTheme(sel){
				var preferred = sel.options[sel.selectedIndex].value;
				document.preferred_theme_form.preferred_theme.value = preferred;
				document.preferred_theme_form.submit();
			}
			var spinner = new Image();
			spinner.src = '<?php echo $this->themePath('img/spinner.gif') ?>';
			function refreshSecurityCode(imgSelector){
				$(imgSelector).attr('src', spinner.src);
				var clean = <?php echo Flux::config('UseCleanUrls') ? 'true' : 'false' ?>;
				var image = new Image();
				image.src = "<?php echo $this->url('captcha') ?>"+(clean ? '?nocache=' : '&nocache=')+Math.random();
				$(imgSelector).attr('src', image.src);
			}
			function toggleSearchForm()
			{
				$('.search-form').slideToggle('fast');
			}
		</script>
		<?php if (Flux::config('EnableReCaptcha')): ?>
			<script src='https://www.google.com/recaptcha/api.js'></script>
		<?php endif ?>
	</head>
	<body>
		<?php $EADev = include $this->themePath('main/EADevConfig.php', true); ?>
		<div id="wrapper">
			<div id="main">
				<div class="header">
					<a href="<?php echo $this->url('main'); ?>" class="logo"><img src="<?php echo $this->themePath('img/logo.png'); ?>" alt=""></a>
					<div class="menu-item">
						<img class="skull" src="<?php echo $this->themePath('img/skull.png'); ?>" alt="">
						<div class="marquee">
							<marquee behavior="" direction="">welcome to your ragnarok online</marquee>
						</div>
						<div class="server-time">
							<?php echo date('H:i A'); ?>
						</div>
						<div class="menus">
							<ul>
								<li><a href="<?php echo $this->url('main'); ?>">inicio</a></li>
								<li><a href="<?php echo $EADev['forum']; ?>" target="_blank">foro</a></li>
								<li><a href="<?php echo $this->url('main','features'); ?>">características</a></li>
								<li><a href="<?php echo $this->url('ranking','character'); ?>">ranking</a></li>
								<li><a href="<?php echo $this->url('donate'); ?>">donaciones</a></li>
								<li><a href="<?php echo $this->url('main','download'); ?>">descargas</a></li>
							</ul>
						</div>
					</div>
					<a href="<?php echo $this->url('account','create'); ?>" class="register"><img src="<?php echo $this->themePath('img/register-btn.png'); ?>" alt=""></a>
					<?php include $this->themePath('main/status.php', true); ?>
				</div>
				<div class="container">
					<div class="container-left">
						<div class="account-panel">
							<?php include $this->themePath('main/loginpanel.php', true); ?>
						</div>
						<div class="buttons">
							<ul>
								<li><a href="<?php echo $this->url('vote'); ?>"><img src="<?php echo $this->themePath('img/buttons.png'); ?>" alt=""></a></li>
								<li><a href="<?php echo $EADev['rms']; ?>" target="_blank"><img src="<?php echo $this->themePath('img/buttons.png'); ?>" alt=""></a></li>
								<li><a href="<?php echo $this->url('main','freebies'); ?>"><img src="<?php echo $this->themePath('img/buttons.png'); ?>" alt=""></a></li>
								<li><a href="<?php echo $this->url('main','support'); ?>"><img src="<?php echo $this->themePath('img/buttons.png'); ?>" alt=""></a></li>
							</ul>
						</div>
						<div class="database">
							<form action="">
								<div class="database-top">
									<span class="addon"><img src="<?php echo $this->themePath('img/magnifier.png'); ?>" alt=""></span>
									<input type="text" name="name">
								</div>
								<div class="database-bottom">
									<div class="radios">
										<label for="item">
											<input type="radio" id="item" name="module" value="item" checked="checked">
											<img src="<?php echo $this->themePath('img/search-item.png'); ?>" alt="">
										</label>
										<label for="monster">
											<input type="radio" id="monster" name="module" value="monster">
											<img src="<?php echo $this->themePath('img/search-item.png'); ?>" alt="">
										</label>
									</div>
									<div class="searchBtn">
										<input type="submit">
									</div>
								</div>
							</form>
						</div>
						<div class="social">
							<div class="social-header">
								<ul>
									<?php if( $EADev['Facebook'] ): ?>
									<li><a href="<?php echo $EADev['Facebook']; ?>" class="facebook" target="_blank"><img src="<?php echo $this->themePath('img/social-icons.png'); ?>" alt=""></a></li>
									<?php endif; ?>
									<?php if( $EADev['Twitter'] ): ?>
									<li><a href="<?php echo $EADev['Twitter']; ?>" class="twitter" target="_blank"><img src="<?php echo $this->themePath('img/social-icons.png'); ?>" alt=""></a></li>
									<?php endif; ?>
									<?php if( $EADev['Youtube'] ): ?>
									<li><a href="<?php echo $EADev['Youtube']; ?>" class="youtube" target="_blank"><img src="<?php echo $this->themePath('img/social-icons.png'); ?>" alt=""></a></li>
									<?php endif; ?>
								</ul>
							</div>
							<div class="social-body">
								<iframe src="//www.facebook.com/plugins/likebox.php?href=<?php echo $EADev['Facebook']; ?>&amp;width=265&amp;height=165&amp;colorscheme=light&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=false" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:165px;" allowtransparency="true"></iframe>
							</div>
						</div>
					</div>
					<div class="container-middle">
						<div class="container-inner">
							<?php if ($message=$session->getMessage()): ?>
								<p class="message"><?php echo htmlspecialchars($message) ?></p>
							<?php endif ?>
							<?php include $this->themePath('main/submenu.php', true); ?>
							<?php include $this->themePath('main/pagemenu.php', true); ?>
							<?php if (in_array($params->get('module'), array('donate', 'purchase'))) include $this->themePath('main/balance.php', true) ?>